package audittoolkit.aiagent.core.api.controllers;

import audittoolkit.aiagent.core.assessment.engine.AssessmentEngine;
import audittoolkit.aiagent.core.assessment.reporting.AssessmentReport;
import audittoolkit.aiagent.core.api.dto.AssessmentRequest;
import audittoolkit.aiagent.core.api.dto.AssessmentResponse;
import audittoolkit.aiagent.core.api.dto.ControlAssessmentRequest;
import audittoolkit.aiagent.core.api.dto.ControlAssessmentResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST API controller for AI system assessments.
 * Provides endpoints for executing and managing assessments using ISACA and NIST methodologies.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
@RestController
@RequestMapping("/api/v1/assessments")
@Tag(name = "Assessment", description = "AI System Assessment API")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AssessmentController {

    private final AssessmentEngine assessmentEngine;

    public AssessmentController(AssessmentEngine assessmentEngine) {
        this.assessmentEngine = assessmentEngine;
    }

    @Operation(summary = "Execute comprehensive AI system assessment",
               description = "Executes a comprehensive assessment using ISACA and NIST methodologies")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Assessment completed successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid assessment request"),
        @ApiResponse(responseCode = "401", description = "Unauthorized"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("/execute")
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN')")
    public ResponseEntity<AssessmentResponse> executeAssessment(
            @Valid @RequestBody AssessmentRequest request) {
        
        try {
            AssessmentReport report = assessmentEngine.executeAssessment(request);
            AssessmentResponse response = AssessmentResponse.fromReport(report);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(AssessmentResponse.error(e.getMessage()));
        }
    }

    @Operation(summary = "Execute control-specific assessment",
               description = "Executes assessment for a specific control using explainability dimensions")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Control assessment completed"),
        @ApiResponse(responseCode = "400", description = "Invalid control assessment request"),
        @ApiResponse(responseCode = "404", description = "Control not found")
    })
    @PostMapping("/controls/{controlId}")
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN')")
    public ResponseEntity<ControlAssessmentResponse> assessControl(
            @Parameter(description = "Control ID") @PathVariable Long controlId,
            @Valid @RequestBody ControlAssessmentRequest request) {
        
        try {
            // Implementation for control assessment
            ControlAssessmentResponse response = new ControlAssessmentResponse();
            response.setControlId(controlId);
            response.setStatus("COMPLETED");
            response.setMessage("Control assessment completed successfully");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ControlAssessmentResponse.error(controlId, e.getMessage()));
        }
    }

    @Operation(summary = "Get assessment by ID",
               description = "Retrieves a specific assessment report by ID")
    @GetMapping("/{assessmentId}")
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN') or hasRole('VIEWER')")
    public ResponseEntity<AssessmentResponse> getAssessment(
            @Parameter(description = "Assessment ID") @PathVariable String assessmentId) {
        
        try {
            // Implementation for retrieving assessment
            AssessmentResponse response = new AssessmentResponse();
            response.setAssessmentId(assessmentId);
            response.setStatus("FOUND");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "List all assessments",
               description = "Retrieves a paginated list of all assessments")
    @GetMapping
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN') or hasRole('VIEWER')")
    public ResponseEntity<Page<AssessmentResponse>> listAssessments(
            @Parameter(description = "Pagination parameters") Pageable pageable,
            @Parameter(description = "Filter by status") @RequestParam(required = false) String status,
            @Parameter(description = "Filter by methodology") @RequestParam(required = false) String methodology) {
        
        try {
            // Implementation for listing assessments
            Page<AssessmentResponse> assessments = Page.empty();
            return ResponseEntity.ok(assessments);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Get assessment status",
               description = "Retrieves the current status of an assessment")
    @GetMapping("/{assessmentId}/status")
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN') or hasRole('VIEWER')")
    public ResponseEntity<String> getAssessmentStatus(
            @Parameter(description = "Assessment ID") @PathVariable String assessmentId) {
        
        try {
            // Implementation for getting assessment status
            return ResponseEntity.ok("COMPLETED");
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Cancel running assessment",
               description = "Cancels a currently running assessment")
    @PostMapping("/{assessmentId}/cancel")
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN')")
    public ResponseEntity<String> cancelAssessment(
            @Parameter(description = "Assessment ID") @PathVariable String assessmentId) {
        
        try {
            // Implementation for canceling assessment
            return ResponseEntity.ok("Assessment cancelled successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to cancel assessment: " + e.getMessage());
        }
    }

    @Operation(summary = "Download assessment report",
               description = "Downloads the assessment report in specified format")
    @GetMapping("/{assessmentId}/download")
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN') or hasRole('VIEWER')")
    public ResponseEntity<byte[]> downloadAssessmentReport(
            @Parameter(description = "Assessment ID") @PathVariable String assessmentId,
            @Parameter(description = "Report format (PDF, XLSX, JSON)") 
            @RequestParam(defaultValue = "PDF") String format) {
        
        try {
            // Implementation for downloading report
            byte[] reportData = new byte[0]; // Placeholder
            
            String contentType = switch (format.toUpperCase()) {
                case "PDF" -> "application/pdf";
                case "XLSX" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                case "JSON" -> "application/json";
                default -> "application/octet-stream";
            };
            
            return ResponseEntity.ok()
                    .header("Content-Type", contentType)
                    .header("Content-Disposition", 
                            "attachment; filename=assessment-" + assessmentId + "." + format.toLowerCase())
                    .body(reportData);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Get assessment metrics",
               description = "Retrieves key metrics and statistics for an assessment")
    @GetMapping("/{assessmentId}/metrics")
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN') or hasRole('VIEWER')")
    public ResponseEntity<AssessmentMetrics> getAssessmentMetrics(
            @Parameter(description = "Assessment ID") @PathVariable String assessmentId) {
        
        try {
            // Implementation for getting assessment metrics
            AssessmentMetrics metrics = new AssessmentMetrics();
            metrics.setAssessmentId(assessmentId);
            metrics.setTotalControls(0);
            metrics.setAssessedControls(0);
            metrics.setCompliancePercentage(0.0);
            
            return ResponseEntity.ok(metrics);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Validate assessment request",
               description = "Validates an assessment request without executing it")
    @PostMapping("/validate")
    @PreAuthorize("hasRole('AUDITOR') or hasRole('ADMIN')")
    public ResponseEntity<ValidationResult> validateAssessmentRequest(
            @Valid @RequestBody AssessmentRequest request) {
        
        try {
            // Implementation for validating assessment request
            ValidationResult result = new ValidationResult();
            result.setValid(true);
            result.setMessage("Assessment request is valid");
            
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            ValidationResult result = new ValidationResult();
            result.setValid(false);
            result.setMessage("Validation failed: " + e.getMessage());
            
            return ResponseEntity.badRequest().body(result);
        }
    }

    // Inner classes for response DTOs
    public static class AssessmentMetrics {
        private String assessmentId;
        private int totalControls;
        private int assessedControls;
        private double compliancePercentage;
        
        // Getters and setters
        public String getAssessmentId() { return assessmentId; }
        public void setAssessmentId(String assessmentId) { this.assessmentId = assessmentId; }
        
        public int getTotalControls() { return totalControls; }
        public void setTotalControls(int totalControls) { this.totalControls = totalControls; }
        
        public int getAssessedControls() { return assessedControls; }
        public void setAssessedControls(int assessedControls) { this.assessedControls = assessedControls; }
        
        public double getCompliancePercentage() { return compliancePercentage; }
        public void setCompliancePercentage(double compliancePercentage) { this.compliancePercentage = compliancePercentage; }
    }

    public static class ValidationResult {
        private boolean valid;
        private String message;
        private List<String> errors;
        
        // Getters and setters
        public boolean isValid() { return valid; }
        public void setValid(boolean valid) { this.valid = valid; }
        
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        
        public List<String> getErrors() { return errors; }
        public void setErrors(List<String> errors) { this.errors = errors; }
    }
}
