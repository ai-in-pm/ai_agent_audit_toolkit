package audittoolkit.aiagent.core.framework.controls;

/**
 * Control effectiveness levels based on assessment results.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum ControlEffectiveness {
    
    NOT_ASSESSED("Not Assessed", "Control has not been assessed yet"),
    INEFFECTIVE("Ineffective", "Control is not working as intended"),
    PARTIALLY_EFFECTIVE("Partially Effective", "Control is working but has deficiencies"),
    LARGELY_EFFECTIVE("Largely Effective", "Control is working well with minor issues"),
    FULLY_EFFECTIVE("Fully Effective", "Control is working as designed");

    private final String displayName;
    private final String description;

    ControlEffectiveness(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this effectiveness level indicates control issues
     */
    public boolean indicatesIssues() {
        return this == INEFFECTIVE || this == PARTIALLY_EFFECTIVE;
    }

    /**
     * Get effectiveness score (0-100)
     */
    public int getEffectivenessScore() {
        switch (this) {
            case NOT_ASSESSED: return 0;
            case INEFFECTIVE: return 20;
            case PARTIALLY_EFFECTIVE: return 50;
            case LARGELY_EFFECTIVE: return 80;
            case FULLY_EFFECTIVE: return 100;
            default: return 0;
        }
    }

    /**
     * Get color code for UI representation
     */
    public String getColorCode() {
        switch (this) {
            case NOT_ASSESSED: return "#6c757d";     // Gray
            case INEFFECTIVE: return "#dc3545";      // Red
            case PARTIALLY_EFFECTIVE: return "#fd7e14"; // Orange
            case LARGELY_EFFECTIVE: return "#ffc107";   // Yellow
            case FULLY_EFFECTIVE: return "#28a745";     // Green
            default: return "#6c757d";                  // Gray
        }
    }

    /**
     * Get effectiveness from score
     */
    public static ControlEffectiveness fromScore(int score) {
        if (score >= 90) return FULLY_EFFECTIVE;
        if (score >= 70) return LARGELY_EFFECTIVE;
        if (score >= 40) return PARTIALLY_EFFECTIVE;
        if (score > 0) return INEFFECTIVE;
        return NOT_ASSESSED;
    }

    /**
     * Get required actions based on effectiveness level
     */
    public String[] getRequiredActions() {
        switch (this) {
            case NOT_ASSESSED:
                return new String[]{"Schedule assessment", "Define assessment criteria", "Assign assessor"};
            case INEFFECTIVE:
                return new String[]{"Immediate remediation", "Root cause analysis", "Control redesign"};
            case PARTIALLY_EFFECTIVE:
                return new String[]{"Identify gaps", "Implement improvements", "Enhanced monitoring"};
            case LARGELY_EFFECTIVE:
                return new String[]{"Minor adjustments", "Continuous monitoring", "Regular review"};
            case FULLY_EFFECTIVE:
                return new String[]{"Maintain current state", "Periodic review", "Document best practices"};
            default:
                return new String[]{};
        }
    }
}
