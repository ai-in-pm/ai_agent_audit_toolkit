package audittoolkit.aiagent.core.framework.controls;

/**
 * Control domains for organizing ISACA AI Audit Toolkit controls.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum ControlDomain {
    
    GOVERNANCE("Governance", "Controls related to AI governance, strategy, and oversight"),
    SECURITY("Security", "Controls focused on protecting AI systems from threats and vulnerabilities"),
    PRIVACY("Privacy", "Controls ensuring data privacy and protection of personal information"),
    ETHICS("Ethics", "Controls addressing ethical considerations and bias in AI systems"),
    OPERATIONS("Operations", "Controls for operational management and monitoring of AI systems"),
    COMPLIANCE("Compliance", "Controls ensuring adherence to regulations and standards"),
    RISK_MANAGEMENT("Risk Management", "Controls for identifying, assessing, and mitigating AI risks"),
    QUALITY_ASSURANCE("Quality Assurance", "Controls ensuring AI system quality and reliability");

    private final String displayName;
    private final String description;

    ControlDomain(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this domain is regulatory-focused
     */
    public boolean isRegulatoryFocused() {
        return this == COMPLIANCE || this == PRIVACY || this == ETHICS;
    }

    /**
     * Check if this domain is technical-focused
     */
    public boolean isTechnicalFocused() {
        return this == SECURITY || this == OPERATIONS || this == QUALITY_ASSURANCE;
    }

    /**
     * Check if this domain is management-focused
     */
    public boolean isManagementFocused() {
        return this == GOVERNANCE || this == RISK_MANAGEMENT;
    }

    /**
     * Get associated regulatory frameworks
     */
    public String[] getAssociatedFrameworks() {
        switch (this) {
            case GOVERNANCE:
                return new String[]{"NIST AI RMF", "ISO/IEC 23053", "COBIT"};
            case SECURITY:
                return new String[]{"NIST 800-53", "ISO 27001", "OWASP ML Top 10"};
            case PRIVACY:
                return new String[]{"GDPR", "CCPA", "ISO 27701"};
            case ETHICS:
                return new String[]{"EU AI Act", "IEEE 2857", "Partnership on AI"};
            case OPERATIONS:
                return new String[]{"ITIL", "ISO 20000", "NIST Cybersecurity Framework"};
            case COMPLIANCE:
                return new String[]{"SOX", "HIPAA", "PCI DSS", "EU AI Act"};
            case RISK_MANAGEMENT:
                return new String[]{"ISO 31000", "COSO ERM", "NIST RMF"};
            case QUALITY_ASSURANCE:
                return new String[]{"ISO 9001", "CMMI", "IEEE 730"};
            default:
                return new String[]{};
        }
    }

    /**
     * Get domain-specific assessment focus areas
     */
    public String[] getAssessmentFocusAreas() {
        switch (this) {
            case GOVERNANCE:
                return new String[]{"Policy framework", "Oversight structure", "Strategic alignment"};
            case SECURITY:
                return new String[]{"Threat protection", "Vulnerability management", "Access controls"};
            case PRIVACY:
                return new String[]{"Data protection", "Consent management", "Privacy by design"};
            case ETHICS:
                return new String[]{"Bias detection", "Fairness metrics", "Ethical guidelines"};
            case OPERATIONS:
                return new String[]{"Performance monitoring", "Incident response", "Change management"};
            case COMPLIANCE:
                return new String[]{"Regulatory adherence", "Audit trails", "Documentation"};
            case RISK_MANAGEMENT:
                return new String[]{"Risk identification", "Risk assessment", "Mitigation strategies"};
            case QUALITY_ASSURANCE:
                return new String[]{"Testing procedures", "Quality metrics", "Validation processes"};
            default:
                return new String[]{};
        }
    }
}
