package audittoolkit.aiagent.core.framework.controls;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a control family in the ISACA AI Audit Toolkit.
 * Control families group related controls for ease in scoping assessments.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
@Entity
@Table(name = "control_families")
public class ControlFamily {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(unique = true, nullable = false)
    private String code;

    @NotBlank
    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @NotNull
    private ControlPriority priority;

    @Enumerated(EnumType.STRING)
    @NotNull
    private ControlDomain domain;

    @OneToMany(mappedBy = "controlFamily", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ControlCategory> controlCategories = new ArrayList<>();

    @Column(nullable = false)
    private Boolean isActive = true;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public ControlFamily() {}

    public ControlFamily(String code, String name, String description, 
                        ControlPriority priority, ControlDomain domain) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.priority = priority;
        this.domain = domain;
    }

    // ISACA Control Family Factory Methods
    public static ControlFamily createAdversarialDefenseFamily() {
        return new ControlFamily(
            "ADR",
            "Adversarial Defense & Robustness",
            "Focuses on strategies and techniques to protect AI systems against adversarial attacks, ensuring model integrity and reliability",
            ControlPriority.HIGH,
            ControlDomain.SECURITY
        );
    }

    public static ControlFamily createBiasMitigationFamily() {
        return new ControlFamily(
            "BMF",
            "AI Bias Mitigation & Fairness",
            "Dedicated to identifying and mitigating biases in AI systems to ensure fair and unbiased decision-making processes",
            ControlPriority.CRITICAL,
            ControlDomain.ETHICS
        );
    }

    public static ControlFamily createDataPrivacyFamily() {
        return new ControlFamily(
            "DPR",
            "AI Data Privacy & Rights",
            "Addresses the protection of data in AI systems, emphasizing personal data rights and compliance with data protection laws",
            ControlPriority.CRITICAL,
            ControlDomain.PRIVACY
        );
    }

    public static ControlFamily createEcosystemSecurityFamily() {
        return new ControlFamily(
            "ESS",
            "AI Ecosystem Security",
            "Focused on securing the AI ecosystem against external threats, ensuring the security of operations and data",
            ControlPriority.HIGH,
            ControlDomain.SECURITY
        );
    }

    public static ControlFamily createLifecycleManagementFamily() {
        return new ControlFamily(
            "LCM",
            "AI Life Cycle Management",
            "Covers the entire life cycle of AI systems, from development to maintenance, for effective management and improvement",
            ControlPriority.HIGH,
            ControlDomain.GOVERNANCE
        );
    }

    public static ControlFamily createModelGovernanceFamily() {
        return new ControlFamily(
            "MGV",
            "AI Model Governance",
            "Focused on the responsible, ethical governance of AI models, ensuring compliance with standards and regulations",
            ControlPriority.CRITICAL,
            ControlDomain.GOVERNANCE
        );
    }

    public static ControlFamily createOperationsFamily() {
        return new ControlFamily(
            "OPS",
            "AI Operations",
            "Involves operational aspects of AI systems, focusing on efficient and effective management",
            ControlPriority.MEDIUM,
            ControlDomain.OPERATIONS
        );
    }

    public static ControlFamily createAssetManagementFamily() {
        return new ControlFamily(
            "ASM",
            "Asset Management",
            "Focuses on managing assets in AI systems, ensuring optimal use and security",
            ControlPriority.MEDIUM,
            ControlDomain.OPERATIONS
        );
    }

    public static ControlFamily createAuditComplianceFamily() {
        return new ControlFamily(
            "AUD",
            "Audit & Compliance",
            "Involves auditing AI systems for compliance with laws and internal policies, ensuring accountability",
            ControlPriority.HIGH,
            ControlDomain.COMPLIANCE
        );
    }

    public static ControlFamily createBusinessContinuityFamily() {
        return new ControlFamily(
            "BCM",
            "Business Continuity",
            "Dedicated to maintaining and restoring business operations with AI during disruptions for continuous operation",
            ControlPriority.MEDIUM,
            ControlDomain.OPERATIONS
        );
    }

    public static ControlFamily createDataProtectionFamily() {
        return new ControlFamily(
            "DPT",
            "Data Protection",
            "Focuses on safeguarding AI system data against unauthorized access and breaches",
            ControlPriority.HIGH,
            ControlDomain.SECURITY
        );
    }

    public static ControlFamily createEthicalGovernanceFamily() {
        return new ControlFamily(
            "ETH",
            "Ethical AI Governance & Accountability",
            "Encompasses ethical considerations and accountability mechanisms in AI systems",
            ControlPriority.CRITICAL,
            ControlDomain.ETHICS
        );
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public ControlPriority getPriority() { return priority; }
    public void setPriority(ControlPriority priority) { this.priority = priority; }

    public ControlDomain getDomain() { return domain; }
    public void setDomain(ControlDomain domain) { this.domain = domain; }

    public List<ControlCategory> getControlCategories() { return controlCategories; }
    public void setControlCategories(List<ControlCategory> controlCategories) { this.controlCategories = controlCategories; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    /**
     * Add a control category to this family
     */
    public void addControlCategory(ControlCategory category) {
        controlCategories.add(category);
        category.setControlFamily(this);
    }

    /**
     * Remove a control category from this family
     */
    public void removeControlCategory(ControlCategory category) {
        controlCategories.remove(category);
        category.setControlFamily(null);
    }

    /**
     * Get total number of controls in this family
     */
    public int getTotalControlCount() {
        return controlCategories.stream()
                .mapToInt(category -> category.getControls().size())
                .sum();
    }

    @Override
    public String toString() {
        return "ControlFamily{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", priority=" + priority +
                ", domain=" + domain +
                ", categoriesCount=" + controlCategories.size() +
                '}';
    }
}
