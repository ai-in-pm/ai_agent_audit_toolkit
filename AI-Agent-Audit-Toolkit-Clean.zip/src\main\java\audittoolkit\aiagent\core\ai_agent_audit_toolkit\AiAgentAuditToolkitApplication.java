package audittoolkit.aiagent.core.ai_agent_audit_toolkit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Main application class for AI Agent Audit Toolkit.
 *
 * This application provides comprehensive audit capabilities for AI systems
 * implementing ISACA AI Audit Toolkit and NIST AI Risk Management Framework methodologies.
 *
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
@SpringBootApplication(scanBasePackages = "audittoolkit.aiagent.core")
@EntityScan(basePackages = "audittoolkit.aiagent.core.framework")
@EnableJpaRepositories(basePackages = "audittoolkit.aiagent.core.repository")
@EnableCaching
@EnableAsync
@EnableScheduling
@EnableTransactionManagement
public class AiAgentAuditToolkitApplication {

    public static void main(String[] args) {
        System.out.println("Starting AI Agent Audit Toolkit...");
        System.out.println("© 2024 Darrell Mesa. All rights reserved.");
        System.out.println("Owner: Darrell Mesa (darrell.mesa@pm-ss.org)");
        System.out.println("Not for commercial use.");
        System.out.println("========================================");

        SpringApplication.run(AiAgentAuditToolkitApplication.class, args);

        System.out.println("AI Agent Audit Toolkit started successfully!");
        System.out.println("Access the application at: http://localhost:8080");
        System.out.println("API Documentation: http://localhost:8080/swagger-ui.html");
    }
}
