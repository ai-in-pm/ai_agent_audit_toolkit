package audittoolkit.aiagent.core.framework.controls;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a control category within a control family in the ISACA AI Audit Toolkit.
 * Control categories group related controls for more granular organization.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
@Entity
@Table(name = "control_categories")
public class ControlCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String code;

    @NotBlank
    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "control_family_id", nullable = false)
    @NotNull
    private ControlFamily controlFamily;

    @OneToMany(mappedBy = "controlCategory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Control> controls = new ArrayList<>();

    @Enumerated(EnumType.STRING)
    @NotNull
    private ControlPriority priority;

    @Column(nullable = false)
    private Boolean isActive = true;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public ControlCategory() {}

    public ControlCategory(String code, String name, String description, 
                          ControlFamily controlFamily, ControlPriority priority) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.controlFamily = controlFamily;
        this.priority = priority;
    }

    // Factory methods for common control categories
    public static ControlCategory createAdversarialTestingCategory(ControlFamily family) {
        return new ControlCategory(
            "ADR-01",
            "Adversarial Testing",
            "Controls for testing AI systems against adversarial attacks and ensuring robustness",
            family,
            ControlPriority.HIGH
        );
    }

    public static ControlCategory createModelSecurityCategory(ControlFamily family) {
        return new ControlCategory(
            "ADR-02",
            "Model Security",
            "Controls for securing AI models against tampering and unauthorized access",
            family,
            ControlPriority.CRITICAL
        );
    }

    public static ControlCategory createBiasDetectionCategory(ControlFamily family) {
        return new ControlCategory(
            "BMF-01",
            "Bias Detection",
            "Controls for identifying and measuring bias in AI systems",
            family,
            ControlPriority.CRITICAL
        );
    }

    public static ControlCategory createFairnessAssessmentCategory(ControlFamily family) {
        return new ControlCategory(
            "BMF-02",
            "Fairness Assessment",
            "Controls for evaluating fairness across different demographic groups",
            family,
            ControlPriority.HIGH
        );
    }

    public static ControlCategory createDataMinimizationCategory(ControlFamily family) {
        return new ControlCategory(
            "DPR-01",
            "Data Minimization",
            "Controls ensuring minimal data collection and processing",
            family,
            ControlPriority.HIGH
        );
    }

    public static ControlCategory createConsentManagementCategory(ControlFamily family) {
        return new ControlCategory(
            "DPR-02",
            "Consent Management",
            "Controls for managing user consent and data subject rights",
            family,
            ControlPriority.CRITICAL
        );
    }

    public static ControlCategory createModelGovernanceCategory(ControlFamily family) {
        return new ControlCategory(
            "MGV-01",
            "Model Governance",
            "Controls for governing AI model development and deployment",
            family,
            ControlPriority.CRITICAL
        );
    }

    public static ControlCategory createModelValidationCategory(ControlFamily family) {
        return new ControlCategory(
            "MGV-02",
            "Model Validation",
            "Controls for validating AI model performance and reliability",
            family,
            ControlPriority.HIGH
        );
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public ControlFamily getControlFamily() { return controlFamily; }
    public void setControlFamily(ControlFamily controlFamily) { this.controlFamily = controlFamily; }

    public List<Control> getControls() { return controls; }
    public void setControls(List<Control> controls) { this.controls = controls; }

    public ControlPriority getPriority() { return priority; }
    public void setPriority(ControlPriority priority) { this.priority = priority; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    /**
     * Add a control to this category
     */
    public void addControl(Control control) {
        controls.add(control);
        control.setControlCategory(this);
    }

    /**
     * Remove a control from this category
     */
    public void removeControl(Control control) {
        controls.remove(control);
        control.setControlCategory(null);
    }

    /**
     * Get the full code including family prefix
     */
    public String getFullCode() {
        return controlFamily.getCode() + "-" + code;
    }

    /**
     * Calculate category completion percentage
     */
    public double getCompletionPercentage() {
        if (controls.isEmpty()) return 0.0;
        
        long implementedControls = controls.stream()
                .mapToLong(control -> control.getIsImplemented() ? 1 : 0)
                .sum();
        
        return (double) implementedControls / controls.size() * 100.0;
    }

    @Override
    public String toString() {
        return "ControlCategory{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", family='" + (controlFamily != null ? controlFamily.getName() : "null") + '\'' +
                ", priority=" + priority +
                ", controlsCount=" + controls.size() +
                '}';
    }
}
