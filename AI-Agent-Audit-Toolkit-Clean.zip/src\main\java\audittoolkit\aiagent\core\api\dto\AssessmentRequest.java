package audittoolkit.aiagent.core.api.dto;

import audittoolkit.aiagent.core.framework.explainability.ExplainabilityType;
import audittoolkit.aiagent.core.framework.lifecycle.AILifecycleStage;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

/**
 * Request DTO for AI system assessments.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public class AssessmentRequest {

    @NotBlank(message = "System name is required")
    private String systemName;

    @NotBlank(message = "System description is required")
    private String systemDescription;

    @NotNull(message = "Assessment methodology is required")
    private AssessmentMethodologyType methodology;

    @NotEmpty(message = "At least one explainability dimension is required")
    private Set<ExplainabilityType> explainabilityDimensions;

    @NotEmpty(message = "At least one lifecycle stage is required")
    private Set<AILifecycleStage> lifecycleStages;

    @NotEmpty(message = "At least one control family is required")
    private List<String> controlFamilyCodes;

    @NotEmpty(message = "At least one risk category is required")
    private List<String> riskCategoryCodes;

    private Set<RegulatoryFrameworkType> regulatoryFrameworks;

    private AssessmentScope scope;

    private AssessmentPriority priority = AssessmentPriority.MEDIUM;

    private boolean includeAutomatedEvidence = true;

    private boolean generateDetailedReport = true;

    private List<String> notificationEmails;

    private String requestedBy;

    private String organizationUnit;

    // Constructors
    public AssessmentRequest() {}

    public AssessmentRequest(String systemName, String systemDescription, 
                           AssessmentMethodologyType methodology) {
        this.systemName = systemName;
        this.systemDescription = systemDescription;
        this.methodology = methodology;
    }

    // Getters and Setters
    public String getSystemName() { return systemName; }
    public void setSystemName(String systemName) { this.systemName = systemName; }

    public String getSystemDescription() { return systemDescription; }
    public void setSystemDescription(String systemDescription) { this.systemDescription = systemDescription; }

    public AssessmentMethodologyType getMethodology() { return methodology; }
    public void setMethodology(AssessmentMethodologyType methodology) { this.methodology = methodology; }

    public Set<ExplainabilityType> getExplainabilityDimensions() { return explainabilityDimensions; }
    public void setExplainabilityDimensions(Set<ExplainabilityType> explainabilityDimensions) { 
        this.explainabilityDimensions = explainabilityDimensions; 
    }

    public Set<AILifecycleStage> getLifecycleStages() { return lifecycleStages; }
    public void setLifecycleStages(Set<AILifecycleStage> lifecycleStages) { this.lifecycleStages = lifecycleStages; }

    public List<String> getControlFamilyCodes() { return controlFamilyCodes; }
    public void setControlFamilyCodes(List<String> controlFamilyCodes) { this.controlFamilyCodes = controlFamilyCodes; }

    public List<String> getRiskCategoryCodes() { return riskCategoryCodes; }
    public void setRiskCategoryCodes(List<String> riskCategoryCodes) { this.riskCategoryCodes = riskCategoryCodes; }

    public Set<RegulatoryFrameworkType> getRegulatoryFrameworks() { return regulatoryFrameworks; }
    public void setRegulatoryFrameworks(Set<RegulatoryFrameworkType> regulatoryFrameworks) { 
        this.regulatoryFrameworks = regulatoryFrameworks; 
    }

    public AssessmentScope getScope() { return scope; }
    public void setScope(AssessmentScope scope) { this.scope = scope; }

    public AssessmentPriority getPriority() { return priority; }
    public void setPriority(AssessmentPriority priority) { this.priority = priority; }

    public boolean isIncludeAutomatedEvidence() { return includeAutomatedEvidence; }
    public void setIncludeAutomatedEvidence(boolean includeAutomatedEvidence) { 
        this.includeAutomatedEvidence = includeAutomatedEvidence; 
    }

    public boolean isGenerateDetailedReport() { return generateDetailedReport; }
    public void setGenerateDetailedReport(boolean generateDetailedReport) { 
        this.generateDetailedReport = generateDetailedReport; 
    }

    public List<String> getNotificationEmails() { return notificationEmails; }
    public void setNotificationEmails(List<String> notificationEmails) { this.notificationEmails = notificationEmails; }

    public String getRequestedBy() { return requestedBy; }
    public void setRequestedBy(String requestedBy) { this.requestedBy = requestedBy; }

    public String getOrganizationUnit() { return organizationUnit; }
    public void setOrganizationUnit(String organizationUnit) { this.organizationUnit = organizationUnit; }

    // Enums
    public enum AssessmentMethodologyType {
        ISACA_ONLY("ISACA AI Audit Toolkit Only"),
        NIST_ONLY("NIST AI Risk Management Framework Only"),
        HYBRID("Combined ISACA and NIST Approach"),
        CUSTOM("Custom Methodology");

        private final String displayName;

        AssessmentMethodologyType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() { return displayName; }
    }

    public enum RegulatoryFrameworkType {
        EU_AI_ACT("EU AI Act"),
        NIST_800_53("NIST 800-53"),
        ISO_27001("ISO/IEC 27001"),
        GDPR("General Data Protection Regulation"),
        CCPA("California Consumer Privacy Act"),
        SOX("Sarbanes-Oxley Act"),
        HIPAA("Health Insurance Portability and Accountability Act"),
        PCI_DSS("Payment Card Industry Data Security Standard");

        private final String displayName;

        RegulatoryFrameworkType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() { return displayName; }
    }

    public enum AssessmentPriority {
        LOW("Low Priority"),
        MEDIUM("Medium Priority"),
        HIGH("High Priority"),
        CRITICAL("Critical Priority");

        private final String displayName;

        AssessmentPriority(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() { return displayName; }
    }

    public static class AssessmentScope {
        private String functionalityDescription;
        private List<String> dataTypes;
        private List<String> userGroups;
        private List<String> geographicRegions;
        private boolean includeThirdPartyComponents = true;
        private boolean includeTrainingData = true;
        private boolean includeModelArchitecture = true;

        // Getters and Setters
        public String getFunctionalityDescription() { return functionalityDescription; }
        public void setFunctionalityDescription(String functionalityDescription) { 
            this.functionalityDescription = functionalityDescription; 
        }

        public List<String> getDataTypes() { return dataTypes; }
        public void setDataTypes(List<String> dataTypes) { this.dataTypes = dataTypes; }

        public List<String> getUserGroups() { return userGroups; }
        public void setUserGroups(List<String> userGroups) { this.userGroups = userGroups; }

        public List<String> getGeographicRegions() { return geographicRegions; }
        public void setGeographicRegions(List<String> geographicRegions) { this.geographicRegions = geographicRegions; }

        public boolean isIncludeThirdPartyComponents() { return includeThirdPartyComponents; }
        public void setIncludeThirdPartyComponents(boolean includeThirdPartyComponents) { 
            this.includeThirdPartyComponents = includeThirdPartyComponents; 
        }

        public boolean isIncludeTrainingData() { return includeTrainingData; }
        public void setIncludeTrainingData(boolean includeTrainingData) { this.includeTrainingData = includeTrainingData; }

        public boolean isIncludeModelArchitecture() { return includeModelArchitecture; }
        public void setIncludeModelArchitecture(boolean includeModelArchitecture) { 
            this.includeModelArchitecture = includeModelArchitecture; 
        }
    }

    @Override
    public String toString() {
        return "AssessmentRequest{" +
                "systemName='" + systemName + '\'' +
                ", methodology=" + methodology +
                ", explainabilityDimensions=" + explainabilityDimensions +
                ", lifecycleStages=" + lifecycleStages +
                ", priority=" + priority +
                '}';
    }
}
