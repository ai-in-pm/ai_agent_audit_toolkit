package audittoolkit.aiagent.core.framework.risk;

/**
 * Risk time scale based on NIST AI Risk Management Framework.
 * Defines when risks may materialize.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum RiskTimeScale {
    
    IMMEDIATE("Immediate", "Risks that materialize immediately or within hours"),
    SHORT_TERM("Short Term", "Risks that materialize within days to weeks"),
    MEDIUM_TERM("Medium Term", "Risks that materialize within months"),
    EXTENDED("Extended", "Risks that materialize over years or longer periods");

    private final String displayName;
    private final String description;

    RiskTimeScale(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this time scale requires immediate response
     */
    public boolean requiresImmediateResponse() {
        return this == IMMEDIATE || this == SHORT_TERM;
    }

    /**
     * Get monitoring frequency in hours
     */
    public int getMonitoringFrequencyHours() {
        switch (this) {
            case IMMEDIATE: return 1;     // Monitor every hour
            case SHORT_TERM: return 6;    // Monitor every 6 hours
            case MEDIUM_TERM: return 24;  // Monitor daily
            case EXTENDED: return 168;    // Monitor weekly
            default: return 24;
        }
    }
}
