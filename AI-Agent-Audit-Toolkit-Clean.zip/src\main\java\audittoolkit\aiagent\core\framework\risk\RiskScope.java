package audittoolkit.aiagent.core.framework.risk;

/**
 * Risk scope levels based on NIST AI Risk Management Framework.
 * Defines the breadth of impact for AI risks.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum RiskScope {
    
    MODEL("Model Level", "Risks that exist at individual model or system levels"),
    APPLICATION("Application Level", "Risks at the application or implementation levels for specific use cases"),
    ECOSYSTEM("Ecosystem Level", "Risks beyond a single system or organizational context, affecting broader ecosystems");

    private final String displayName;
    private final String description;

    RiskScope(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this scope affects multiple organizations
     */
    public boolean isMultiOrganizational() {
        return this == ECOSYSTEM;
    }

    /**
     * Get the relative impact scale (1-3)
     */
    public int getImpactScale() {
        switch (this) {
            case MODEL: return 1;
            case APPLICATION: return 2;
            case ECOSYSTEM: return 3;
            default: return 1;
        }
    }
}


