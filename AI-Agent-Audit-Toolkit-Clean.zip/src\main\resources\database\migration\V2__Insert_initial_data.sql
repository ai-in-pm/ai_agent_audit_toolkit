-- AI Agent Audit Toolkit Initial Data
-- © 2024 Darrell Mesa. All rights reserved.
-- Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
-- Not for commercial use.

-- Insert NIST GAI Risk Categories
INSERT INTO risk_categories (code, name, description, severity, likelihood, scope, time_scale, is_gai_specific) VALUES
('CBRN_INFO', 'CBRN Information or Capabilities', 
 'Eased access to or synthesis of materially nefarious information or design capabilities related to chemical, biological, radiological, or nuclear (CBRN) weapons or other dangerous materials or agents.',
 'CRITICAL', 'LOW', 'ECOSYSTEM', 'IMMEDIATE', true),

('CONFABULATION', 'Confabulation', 
 'The production of confidently stated but erroneous or false content (known colloquially as "hallucinations" or "fabrications") by which users may be misled or deceived.',
 'HIGH', 'HIGH', 'APPLICATION', 'IMMEDIATE', true),

('DANGEROUS_CONTENT', 'Dangerous, Violent, or Hateful Content', 
 'Eased production of and access to violent, inciting, radicalizing, or threatening content as well as recommendations to carry out self-harm or conduct illegal activities.',
 'CRITICAL', 'MEDIUM', 'ECOSYSTEM', 'IMMEDIATE', true),

('DATA_PRIVACY', 'Data Privacy', 
 'Impacts due to leakage and unauthorized use, disclosure, or de-anonymization of biometric, health, location, or other personally identifiable information or sensitive data.',
 'HIGH', 'MEDIUM', 'APPLICATION', 'EXTENDED', true),

('ENVIRONMENTAL', 'Environmental Impacts', 
 'Impacts due to high compute resource utilization in training or operating GAI models, and related outcomes that may adversely impact ecosystems.',
 'MEDIUM', 'HIGH', 'ECOSYSTEM', 'EXTENDED', true),

('HARMFUL_BIAS', 'Harmful Bias or Homogenization', 
 'Amplification and exacerbation of historical, societal, and systemic biases; performance disparities between sub-groups or languages that result in discrimination.',
 'HIGH', 'HIGH', 'APPLICATION', 'EXTENDED', true),

('HUMAN_AI_CONFIG', 'Human-AI Configuration', 
 'Arrangements of or interactions between a human and an AI system which can result in inappropriate anthropomorphizing or emotional entanglement.',
 'MEDIUM', 'MEDIUM', 'APPLICATION', 'IMMEDIATE', true),

('INFO_INTEGRITY', 'Information Integrity', 
 'Lowered barrier to entry to generate and support the exchange and consumption of content which may not distinguish fact from opinion or fiction.',
 'HIGH', 'HIGH', 'ECOSYSTEM', 'IMMEDIATE', true),

('INFO_SECURITY', 'Information Security', 
 'Lowered barriers for offensive cyber capabilities, including via automated discovery and exploitation of vulnerabilities.',
 'HIGH', 'MEDIUM', 'APPLICATION', 'IMMEDIATE', true),

('INTELLECTUAL_PROPERTY', 'Intellectual Property', 
 'Eased production or replication of alleged copyrighted, trademarked, or licensed content without authorization.',
 'MEDIUM', 'HIGH', 'APPLICATION', 'IMMEDIATE', true),

('OBSCENE_CONTENT', 'Obscene, Degrading, and/or Abusive Content', 
 'Eased production of and access to obscene, degrading, and/or abusive imagery which can cause harm.',
 'CRITICAL', 'MEDIUM', 'ECOSYSTEM', 'IMMEDIATE', true),

('VALUE_CHAIN', 'Value Chain and Component Integration', 
 'Non-transparent or untraceable integration of upstream third-party components that diminish transparency or accountability.',
 'MEDIUM', 'MEDIUM', 'APPLICATION', 'EXTENDED', true);

-- Insert ISACA Control Families
INSERT INTO control_families (code, name, description, priority, domain) VALUES
('ADR', 'Adversarial Defense & Robustness', 
 'Focuses on strategies and techniques to protect AI systems against adversarial attacks, ensuring model integrity and reliability',
 'HIGH', 'SECURITY'),

('BMF', 'AI Bias Mitigation & Fairness', 
 'Dedicated to identifying and mitigating biases in AI systems to ensure fair and unbiased decision-making processes',
 'CRITICAL', 'ETHICS'),

('DPR', 'AI Data Privacy & Rights', 
 'Addresses the protection of data in AI systems, emphasizing personal data rights and compliance with data protection laws',
 'CRITICAL', 'PRIVACY'),

('ESS', 'AI Ecosystem Security', 
 'Focused on securing the AI ecosystem against external threats, ensuring the security of operations and data',
 'HIGH', 'SECURITY'),

('LCM', 'AI Life Cycle Management', 
 'Covers the entire life cycle of AI systems, from development to maintenance, for effective management and improvement',
 'HIGH', 'GOVERNANCE'),

('MGV', 'AI Model Governance', 
 'Focused on the responsible, ethical governance of AI models, ensuring compliance with standards and regulations',
 'CRITICAL', 'GOVERNANCE'),

('OPS', 'AI Operations', 
 'Involves operational aspects of AI systems, focusing on efficient and effective management',
 'MEDIUM', 'OPERATIONS'),

('ASM', 'Asset Management', 
 'Focuses on managing assets in AI systems, ensuring optimal use and security',
 'MEDIUM', 'OPERATIONS'),

('AUD', 'Audit & Compliance', 
 'Involves auditing AI systems for compliance with laws and internal policies, ensuring accountability',
 'HIGH', 'COMPLIANCE'),

('BCM', 'Business Continuity', 
 'Dedicated to maintaining and restoring business operations with AI during disruptions for continuous operation',
 'MEDIUM', 'OPERATIONS'),

('DPT', 'Data Protection', 
 'Focuses on safeguarding AI system data against unauthorized access and breaches',
 'HIGH', 'SECURITY'),

('ETH', 'Ethical AI Governance & Accountability', 
 'Encompasses ethical considerations and accountability mechanisms in AI systems',
 'CRITICAL', 'ETHICS'),

('EXT', 'External Components & Supply Chain Governance', 
 'Manages and secures external components and supply chains of AI systems',
 'MEDIUM', 'GOVERNANCE'),

('GOV', 'Governance & Strategy', 
 'Involves overarching governance and strategic planning of AI initiatives',
 'HIGH', 'GOVERNANCE'),

('HAI', 'Human-AI Interaction & Experience', 
 'Concerned with interactions between humans and AI systems, focusing on user experience',
 'MEDIUM', 'OPERATIONS'),

('IAM', 'Identity & Access Management', 
 'Includes controls for managing identities and access in AI systems',
 'HIGH', 'SECURITY'),

('INC', 'Incident Management', 
 'Involves handling incidents in AI systems, including response and recovery',
 'HIGH', 'OPERATIONS'),

('LEG', 'Legal, Regulatory, & AI-Prohibited Use Cases', 
 'Addresses legal and regulatory aspects of AI, including compliance and prohibited use cases',
 'CRITICAL', 'COMPLIANCE'),

('RSK', 'Risk Management', 
 'Covers the identification and mitigation of risk associated with AI systems',
 'HIGH', 'RISK_MANAGEMENT'),

('SSD', 'Secure Systems Design & Development', 
 'Covers designing and developing AI systems with embedded security',
 'HIGH', 'SECURITY');

-- Insert Explainability Dimensions
INSERT INTO explainability_dimensions (code, name, description, type) VALUES
('RATIONALE', 'Rationale Explanation', 
 'Focuses on the logical reasoning behind AI decisions; aims to make the decision-making process of AI systems transparent and comprehensible',
 'RATIONALE'),

('RESPONSIBILITY', 'Responsibility Explanation', 
 'Delineates the accountability framework within AI operations, clarifying who or what is responsible for specific decisions and actions',
 'RESPONSIBILITY'),

('DATA', 'Data Explanation', 
 'Focuses on the origin, nature, and processing of data used by AI systems',
 'DATA'),

('FAIRNESS', 'Fairness Explanation', 
 'Addresses how AI systems ensure fairness and avoid bias in their operations',
 'FAIRNESS'),

('SAFETY_PERFORMANCE', 'Safety & Performance Explanation', 
 'Elucidates the measures taken to ensure the safety and optimal performance of AI systems',
 'SAFETY_PERFORMANCE'),

('IMPACT', 'Impact Explanation', 
 'Explores the broader implications of AI systems, including their societal, ethical, environmental, and regulatory impacts',
 'IMPACT');

-- Insert Evidence Types for Explainability Dimensions
INSERT INTO explainability_evidence_types (explainability_dimension_id, evidence_types) VALUES
((SELECT id FROM explainability_dimensions WHERE code = 'RATIONALE'), 'Logic maps'),
((SELECT id FROM explainability_dimensions WHERE code = 'RATIONALE'), 'Decision trees'),
((SELECT id FROM explainability_dimensions WHERE code = 'RATIONALE'), 'Documentation explaining the AI model''s reasoning'),

((SELECT id FROM explainability_dimensions WHERE code = 'RESPONSIBILITY'), 'Accountability matrices'),
((SELECT id FROM explainability_dimensions WHERE code = 'RESPONSIBILITY'), 'Role definitions'),
((SELECT id FROM explainability_dimensions WHERE code = 'RESPONSIBILITY'), 'Documentation of decision ownership'),

((SELECT id FROM explainability_dimensions WHERE code = 'DATA'), 'Data lineage records'),
((SELECT id FROM explainability_dimensions WHERE code = 'DATA'), 'Processing logs'),
((SELECT id FROM explainability_dimensions WHERE code = 'DATA'), 'Data source documentation'),

((SELECT id FROM explainability_dimensions WHERE code = 'FAIRNESS'), 'Fairness metrics reports'),
((SELECT id FROM explainability_dimensions WHERE code = 'FAIRNESS'), 'Bias detection analyses'),
((SELECT id FROM explainability_dimensions WHERE code = 'FAIRNESS'), 'Corrective action plans'),

((SELECT id FROM explainability_dimensions WHERE code = 'SAFETY_PERFORMANCE'), 'Safety protocols'),
((SELECT id FROM explainability_dimensions WHERE code = 'SAFETY_PERFORMANCE'), 'Performance testing results'),
((SELECT id FROM explainability_dimensions WHERE code = 'SAFETY_PERFORMANCE'), 'Maintenance records'),

((SELECT id FROM explainability_dimensions WHERE code = 'IMPACT'), 'Impact assessment reports'),
((SELECT id FROM explainability_dimensions WHERE code = 'IMPACT'), 'Ethical considerations documentation'),
((SELECT id FROM explainability_dimensions WHERE code = 'IMPACT'), 'Sustainability analyses'),
((SELECT id FROM explainability_dimensions WHERE code = 'IMPACT'), 'Compliance and regulatory impact assessment reports');

-- Insert Assessment Types for Explainability Dimensions
INSERT INTO explainability_assessment_types (explainability_dimension_id, assessment_types) VALUES
((SELECT id FROM explainability_dimensions WHERE code = 'RATIONALE'), 'Evaluation of the clarity and logic of the explanations provided by AI models'),
((SELECT id FROM explainability_dimensions WHERE code = 'RESPONSIBILITY'), 'Assessment of clear lines of accountability and responsibility in AI system operations'),
((SELECT id FROM explainability_dimensions WHERE code = 'DATA'), 'Verification of the authenticity, relevance, and integrity of the data used'),
((SELECT id FROM explainability_dimensions WHERE code = 'FAIRNESS'), 'Assessment of mechanisms and practices in place to detect and mitigate bias'),
((SELECT id FROM explainability_dimensions WHERE code = 'SAFETY_PERFORMANCE'), 'Evaluation of the system''s safety features and performance standards'),
((SELECT id FROM explainability_dimensions WHERE code = 'IMPACT'), 'Analysis of the AI system''s impact on users, society, and the environment'),
((SELECT id FROM explainability_dimensions WHERE code = 'IMPACT'), 'Analysis of the impact of legislation, regulations, and frameworks');

-- Insert Assessment Methods for Explainability Dimensions
INSERT INTO explainability_assessment_methods (explainability_dimension_id, assessment_methods) VALUES
((SELECT id FROM explainability_dimensions WHERE code = 'RATIONALE'), 'Reviewing the logical coherence and transparency of decision-making processes in AI models'),
((SELECT id FROM explainability_dimensions WHERE code = 'RESPONSIBILITY'), 'Analyzing documentation and system design to ensure clear assignment of responsibilities'),
((SELECT id FROM explainability_dimensions WHERE code = 'DATA'), 'Inspecting data handling practices, source validation, and data integrity checks'),
((SELECT id FROM explainability_dimensions WHERE code = 'FAIRNESS'), 'Evaluating the effectiveness of bias detection tools and the implementation of fairness guidelines'),
((SELECT id FROM explainability_dimensions WHERE code = 'SAFETY_PERFORMANCE'), 'Reviewing safety compliance documents and performance benchmarking results'),
((SELECT id FROM explainability_dimensions WHERE code = 'IMPACT'), 'Examining comprehensive impact assessments and sustainability strategies'),
((SELECT id FROM explainability_dimensions WHERE code = 'IMPACT'), 'Identifying relevant laws and regulations, evaluating regulatory impact, and assessing level of compliance');

-- Insert Risk Category Lifecycle Stages
INSERT INTO risk_category_lifecycle_stages (risk_category_id, lifecycle_stages) VALUES
((SELECT id FROM risk_categories WHERE code = 'CBRN_INFO'), 'DEVELOPMENT'),
((SELECT id FROM risk_categories WHERE code = 'CBRN_INFO'), 'DEPLOYMENT'),
((SELECT id FROM risk_categories WHERE code = 'CBRN_INFO'), 'OPERATION'),

((SELECT id FROM risk_categories WHERE code = 'CONFABULATION'), 'DEVELOPMENT'),
((SELECT id FROM risk_categories WHERE code = 'CONFABULATION'), 'OPERATION'),

((SELECT id FROM risk_categories WHERE code = 'DANGEROUS_CONTENT'), 'DEVELOPMENT'),
((SELECT id FROM risk_categories WHERE code = 'DANGEROUS_CONTENT'), 'DEPLOYMENT'),
((SELECT id FROM risk_categories WHERE code = 'DANGEROUS_CONTENT'), 'OPERATION'),

((SELECT id FROM risk_categories WHERE code = 'DATA_PRIVACY'), 'DESIGN'),
((SELECT id FROM risk_categories WHERE code = 'DATA_PRIVACY'), 'DEVELOPMENT'),
((SELECT id FROM risk_categories WHERE code = 'DATA_PRIVACY'), 'DEPLOYMENT'),
((SELECT id FROM risk_categories WHERE code = 'DATA_PRIVACY'), 'OPERATION'),
((SELECT id FROM risk_categories WHERE code = 'DATA_PRIVACY'), 'DECOMMISSIONING');

-- Insert Risk Category AI Characteristics
INSERT INTO risk_category_ai_characteristics (risk_category_id, ai_characteristics) VALUES
((SELECT id FROM risk_categories WHERE code = 'CBRN_INFO'), 'SAFE'),
((SELECT id FROM risk_categories WHERE code = 'CBRN_INFO'), 'SECURE_RESILIENT'),

((SELECT id FROM risk_categories WHERE code = 'CONFABULATION'), 'VALID_RELIABLE'),
((SELECT id FROM risk_categories WHERE code = 'CONFABULATION'), 'ACCOUNTABLE_TRANSPARENT'),

((SELECT id FROM risk_categories WHERE code = 'DANGEROUS_CONTENT'), 'SAFE'),
((SELECT id FROM risk_categories WHERE code = 'DANGEROUS_CONTENT'), 'FAIR_BIAS_MANAGED'),

((SELECT id FROM risk_categories WHERE code = 'DATA_PRIVACY'), 'PRIVACY_ENHANCED'),
((SELECT id FROM risk_categories WHERE code = 'DATA_PRIVACY'), 'SECURE_RESILIENT'),

((SELECT id FROM risk_categories WHERE code = 'HARMFUL_BIAS'), 'FAIR_BIAS_MANAGED'),
((SELECT id FROM risk_categories WHERE code = 'HARMFUL_BIAS'), 'EXPLAINABLE_INTERPRETABLE');

-- Create views for easier querying
CREATE VIEW v_control_hierarchy AS
SELECT 
    cf.code as family_code,
    cf.name as family_name,
    cf.domain as family_domain,
    cc.code as category_code,
    cc.name as category_name,
    c.code as control_code,
    c.name as control_name,
    c.priority as control_priority,
    c.type as control_type,
    c.is_implemented,
    c.effectiveness
FROM control_families cf
JOIN control_categories cc ON cf.id = cc.control_family_id
JOIN controls c ON cc.id = c.control_category_id
WHERE cf.is_active = true AND cc.is_active = true AND c.is_active = true;

CREATE VIEW v_risk_summary AS
SELECT 
    code,
    name,
    severity,
    likelihood,
    scope,
    time_scale,
    (CASE 
        WHEN severity = 'CRITICAL' THEN 4
        WHEN severity = 'HIGH' THEN 3
        WHEN severity = 'MEDIUM' THEN 2
        ELSE 1
    END) * (CASE 
        WHEN likelihood = 'VERY_HIGH' THEN 0.9
        WHEN likelihood = 'HIGH' THEN 0.7
        WHEN likelihood = 'MEDIUM' THEN 0.5
        WHEN likelihood = 'LOW' THEN 0.3
        ELSE 0.1
    END) as risk_score
FROM risk_categories
WHERE is_active = true;

COMMENT ON VIEW v_control_hierarchy IS 'Hierarchical view of control families, categories, and controls';
COMMENT ON VIEW v_risk_summary IS 'Summary view of risks with calculated risk scores';
