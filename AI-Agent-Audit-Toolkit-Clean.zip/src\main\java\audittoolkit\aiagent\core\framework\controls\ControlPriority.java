package audittoolkit.aiagent.core.framework.controls;

/**
 * Control priority levels for ISACA AI Audit Toolkit controls.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum ControlPriority {
    
    LOW(1, "Low", "Nice to have controls that provide additional assurance"),
    MEDIUM(2, "Medium", "Important controls that should be implemented when feasible"),
    HIGH(3, "High", "Essential controls that significantly reduce risk"),
    CRITICAL(4, "Critical", "Mandatory controls required for basic AI system safety and compliance");

    private final int level;
    private final String displayName;
    private final String description;

    ControlPriority(int level, String displayName, String description) {
        this.level = level;
        this.displayName = displayName;
        this.description = description;
    }

    public int getLevel() {
        return level;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this priority requires immediate implementation
     */
    public boolean requiresImmediateImplementation() {
        return this == CRITICAL || this == HIGH;
    }

    /**
     * Get implementation timeline in weeks
     */
    public int getImplementationTimelineWeeks() {
        switch (this) {
            case CRITICAL: return 2;   // 2 weeks
            case HIGH: return 4;       // 4 weeks
            case MEDIUM: return 12;    // 12 weeks
            case LOW: return 26;       // 26 weeks
            default: return 12;
        }
    }

    /**
     * Get color code for UI representation
     */
    public String getColorCode() {
        switch (this) {
            case LOW: return "#28a745";      // Green
            case MEDIUM: return "#ffc107";   // Yellow
            case HIGH: return "#fd7e14";     // Orange
            case CRITICAL: return "#dc3545"; // Red
            default: return "#6c757d";       // Gray
        }
    }

    /**
     * Get priority from level number
     */
    public static ControlPriority fromLevel(int level) {
        for (ControlPriority priority : values()) {
            if (priority.level == level) {
                return priority;
            }
        }
        return MEDIUM; // Default
    }
}
