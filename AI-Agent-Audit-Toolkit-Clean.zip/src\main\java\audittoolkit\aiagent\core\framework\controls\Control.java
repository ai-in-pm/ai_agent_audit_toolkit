package audittoolkit.aiagent.core.framework.controls;

import audittoolkit.aiagent.core.framework.lifecycle.AILifecycleStage;
import audittoolkit.aiagent.core.framework.risk.TrustworthyAICharacteristic;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Set;

/**
 * Represents an individual control in the ISACA AI Audit Toolkit.
 * Controls define specific requirements and assessment criteria.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
@Entity
@Table(name = "controls")
public class Control {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String code;

    @NotBlank
    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(columnDefinition = "TEXT")
    private String objective;

    @Column(columnDefinition = "TEXT")
    private String implementationGuidance;

    @Column(columnDefinition = "TEXT")
    private String assessmentProcedure;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "control_category_id", nullable = false)
    @NotNull
    private ControlCategory controlCategory;

    @Enumerated(EnumType.STRING)
    @NotNull
    private ControlPriority priority;

    @Enumerated(EnumType.STRING)
    @NotNull
    private ControlType type;

    @ElementCollection(targetClass = AILifecycleStage.class)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "control_lifecycle_stages")
    private Set<AILifecycleStage> applicableStages;

    @ElementCollection(targetClass = TrustworthyAICharacteristic.class)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "control_ai_characteristics")
    private Set<TrustworthyAICharacteristic> supportedCharacteristics;

    @Column(nullable = false)
    private Boolean isImplemented = false;

    @Column(nullable = false)
    private Boolean isAutomated = false;

    @Column(nullable = false)
    private Boolean isActive = true;

    @Column
    private LocalDateTime lastAssessmentDate;

    @Enumerated(EnumType.STRING)
    private ControlEffectiveness effectiveness;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public Control() {}

    public Control(String code, String name, String description, String objective,
                  ControlCategory controlCategory, ControlPriority priority, ControlType type) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.objective = objective;
        this.controlCategory = controlCategory;
        this.priority = priority;
        this.type = type;
    }

    // Factory methods for common controls
    public static Control createAdversarialTestingControl(ControlCategory category) {
        return new Control(
            "ADR-01-001",
            "Adversarial Attack Testing",
            "Regular testing of AI systems against known adversarial attack patterns",
            "Ensure AI system robustness against adversarial inputs and maintain model integrity",
            category,
            ControlPriority.HIGH,
            ControlType.DETECTIVE
        );
    }

    public static Control createModelIntegrityControl(ControlCategory category) {
        return new Control(
            "ADR-02-001",
            "Model Integrity Verification",
            "Verification of AI model integrity through cryptographic signatures and checksums",
            "Prevent unauthorized modification of AI models and ensure model authenticity",
            category,
            ControlPriority.CRITICAL,
            ControlType.PREVENTIVE
        );
    }

    public static Control createBiasMonitoringControl(ControlCategory category) {
        return new Control(
            "BMF-01-001",
            "Continuous Bias Monitoring",
            "Ongoing monitoring of AI system outputs for bias across demographic groups",
            "Detect and alert on potential bias in AI decision-making processes",
            category,
            ControlPriority.CRITICAL,
            ControlType.DETECTIVE
        );
    }

    public static Control createFairnessMetricsControl(ControlCategory category) {
        return new Control(
            "BMF-02-001",
            "Fairness Metrics Assessment",
            "Regular assessment of fairness metrics including demographic parity and equalized odds",
            "Ensure AI systems meet established fairness criteria across all user groups",
            category,
            ControlPriority.HIGH,
            ControlType.DETECTIVE
        );
    }

    public static Control createDataMinimizationControl(ControlCategory category) {
        return new Control(
            "DPR-01-001",
            "Data Collection Minimization",
            "Ensure only necessary data is collected and processed for AI system operation",
            "Minimize privacy risks by limiting data collection to essential requirements",
            category,
            ControlPriority.HIGH,
            ControlType.PREVENTIVE
        );
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getObjective() { return objective; }
    public void setObjective(String objective) { this.objective = objective; }

    public String getImplementationGuidance() { return implementationGuidance; }
    public void setImplementationGuidance(String implementationGuidance) { this.implementationGuidance = implementationGuidance; }

    public String getAssessmentProcedure() { return assessmentProcedure; }
    public void setAssessmentProcedure(String assessmentProcedure) { this.assessmentProcedure = assessmentProcedure; }

    public ControlCategory getControlCategory() { return controlCategory; }
    public void setControlCategory(ControlCategory controlCategory) { this.controlCategory = controlCategory; }

    public ControlPriority getPriority() { return priority; }
    public void setPriority(ControlPriority priority) { this.priority = priority; }

    public ControlType getType() { return type; }
    public void setType(ControlType type) { this.type = type; }

    public Set<AILifecycleStage> getApplicableStages() { return applicableStages; }
    public void setApplicableStages(Set<AILifecycleStage> applicableStages) { this.applicableStages = applicableStages; }

    public Set<TrustworthyAICharacteristic> getSupportedCharacteristics() { return supportedCharacteristics; }
    public void setSupportedCharacteristics(Set<TrustworthyAICharacteristic> supportedCharacteristics) { this.supportedCharacteristics = supportedCharacteristics; }

    public Boolean getIsImplemented() { return isImplemented; }
    public void setIsImplemented(Boolean isImplemented) { this.isImplemented = isImplemented; }

    public Boolean getIsAutomated() { return isAutomated; }
    public void setIsAutomated(Boolean isAutomated) { this.isAutomated = isAutomated; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public LocalDateTime getLastAssessmentDate() { return lastAssessmentDate; }
    public void setLastAssessmentDate(LocalDateTime lastAssessmentDate) { this.lastAssessmentDate = lastAssessmentDate; }

    public ControlEffectiveness getEffectiveness() { return effectiveness; }
    public void setEffectiveness(ControlEffectiveness effectiveness) { this.effectiveness = effectiveness; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    /**
     * Get the full control code including category and family prefixes
     */
    public String getFullCode() {
        return controlCategory.getControlFamily().getCode() + "-" + code;
    }

    /**
     * Check if control needs assessment based on last assessment date
     */
    public boolean needsAssessment() {
        if (lastAssessmentDate == null) return true;
        
        LocalDateTime assessmentThreshold = LocalDateTime.now().minusMonths(
            priority == ControlPriority.CRITICAL ? 3 : 
            priority == ControlPriority.HIGH ? 6 : 12
        );
        
        return lastAssessmentDate.isBefore(assessmentThreshold);
    }

    @Override
    public String toString() {
        return "Control{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", priority=" + priority +
                ", type=" + type +
                ", implemented=" + isImplemented +
                ", effectiveness=" + effectiveness +
                '}';
    }
}
