package audittoolkit.aiagent.core.framework.risk;

/**
 * Trustworthy AI Characteristics based on NIST AI Risk Management Framework.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum TrustworthyAICharacteristic {
    
    ACCOUNTABLE_TRANSPARENT("Accountable and Transparent", "Systems provide clear accountability and transparency"),
    EXPLAINABLE_INTERPRETABLE("Explainable and Interpretable", "Systems provide explanations for their decisions"),
    FAIR_BIAS_MANAGED("Fair with Harmful Bias Managed", "Systems operate fairly without harmful bias"),
    PRIVACY_ENHANCED("Privacy Enhanced", "Systems protect privacy and personal data"),
    SAFE("Safe", "Systems operate safely without causing harm"),
    SECURE_RESILIENT("Secure and Resilient", "Systems are secure against threats and resilient to failures"),
    VALID_RELIABLE("Valid and Reliable", "Systems produce valid and reliable outputs");

    private final String displayName;
    private final String description;

    TrustworthyAICharacteristic(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this characteristic is related to security
     */
    public boolean isSecurityRelated() {
        return this == SECURE_RESILIENT || this == PRIVACY_ENHANCED;
    }

    /**
     * Check if this characteristic is related to fairness
     */
    public boolean isFairnessRelated() {
        return this == FAIR_BIAS_MANAGED || this == EXPLAINABLE_INTERPRETABLE;
    }

    /**
     * Check if this characteristic is related to transparency
     */
    public boolean isTransparencyRelated() {
        return this == ACCOUNTABLE_TRANSPARENT || this == EXPLAINABLE_INTERPRETABLE;
    }

    /**
     * Get associated assessment criteria
     */
    public String[] getAssessmentCriteria() {
        switch (this) {
            case ACCOUNTABLE_TRANSPARENT:
                return new String[]{"Clear decision trails", "Audit logs", "Responsibility assignment"};
            case EXPLAINABLE_INTERPRETABLE:
                return new String[]{"Model interpretability", "Decision explanations", "Feature importance"};
            case FAIR_BIAS_MANAGED:
                return new String[]{"Bias testing", "Fairness metrics", "Demographic parity"};
            case PRIVACY_ENHANCED:
                return new String[]{"Data protection", "Privacy by design", "Consent management"};
            case SAFE:
                return new String[]{"Safety testing", "Harm prevention", "Risk mitigation"};
            case SECURE_RESILIENT:
                return new String[]{"Security controls", "Threat protection", "System resilience"};
            case VALID_RELIABLE:
                return new String[]{"Performance validation", "Reliability testing", "Accuracy metrics"};
            default:
                return new String[]{};
        }
    }
}
