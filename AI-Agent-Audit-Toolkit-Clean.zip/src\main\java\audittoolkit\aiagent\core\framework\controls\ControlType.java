package audittoolkit.aiagent.core.framework.controls;

/**
 * Control types based on their function in risk mitigation.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum ControlType {
    
    PREVENTIVE("Preventive", "Controls that prevent risks from occurring"),
    DETECTIVE("Detective", "Controls that detect when risks have materialized"),
    CORRECTIVE("Corrective", "Controls that correct issues after they occur"),
    COMPENSATING("Compensating", "Controls that provide alternative risk mitigation"),
    DIRECTIVE("Directive", "Controls that direct or guide behavior through policies");

    private final String displayName;
    private final String description;

    ControlType(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this control type is proactive
     */
    public boolean isProactive() {
        return this == PREVENTIVE || this == DIRECTIVE;
    }

    /**
     * Check if this control type is reactive
     */
    public boolean isReactive() {
        return this == DETECTIVE || this == CORRECTIVE || this == COMPENSATING;
    }

    /**
     * Get typical implementation approaches for this control type
     */
    public String[] getTypicalImplementations() {
        switch (this) {
            case PREVENTIVE:
                return new String[]{"Access controls", "Input validation", "Encryption", "Authentication"};
            case DETECTIVE:
                return new String[]{"Monitoring", "Logging", "Alerting", "Auditing"};
            case CORRECTIVE:
                return new String[]{"Incident response", "Recovery procedures", "Remediation", "Rollback"};
            case COMPENSATING:
                return new String[]{"Alternative controls", "Manual procedures", "Additional monitoring"};
            case DIRECTIVE:
                return new String[]{"Policies", "Procedures", "Standards", "Guidelines"};
            default:
                return new String[]{};
        }
    }
}


