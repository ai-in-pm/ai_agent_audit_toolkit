package audittoolkit.aiagent.core.framework.risk;

/**
 * Risk severity levels for AI systems based on NIST AI Risk Management Framework.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum RiskSeverity {
    
    LOW(1.0, "Low", "Minimal impact on operations, users, or stakeholders"),
    MEDIUM(2.0, "Medium", "Moderate impact that may affect specific functions or user groups"),
    HIGH(3.0, "High", "Significant impact affecting core operations or large user populations"),
    CRITICAL(4.0, "Critical", "Severe impact with potential for widespread harm or system failure");

    private final double weight;
    private final String displayName;
    private final String description;

    RiskSeverity(double weight, String displayName, String description) {
        this.weight = weight;
        this.displayName = displayName;
        this.description = description;
    }

    public double getWeight() {
        return weight;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Get severity level from numeric score
     */
    public static RiskSeverity fromScore(double score) {
        if (score >= 3.5) return CRITICAL;
        if (score >= 2.5) return HIGH;
        if (score >= 1.5) return MEDIUM;
        return LOW;
    }

    /**
     * Check if this severity requires immediate attention
     */
    public boolean requiresImmediateAttention() {
        return this == CRITICAL || this == HIGH;
    }

    /**
     * Get color code for UI representation
     */
    public String getColorCode() {
        switch (this) {
            case LOW: return "#28a745";      // Green
            case MEDIUM: return "#ffc107";   // Yellow
            case HIGH: return "#fd7e14";     // Orange
            case CRITICAL: return "#dc3545"; // Red
            default: return "#6c757d";       // Gray
        }
    }
}
