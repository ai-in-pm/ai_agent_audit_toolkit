package audittoolkit.aiagent.core.framework.lifecycle;

/**
 * AI Lifecycle stages based on NIST AI Risk Management Framework.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum AILifecycleStage {
    
    DESIGN("Design", "Initial design and planning phase"),
    DEVELOPMENT("Development", "Model development and training phase"),
    DEPLOYMENT("Deployment", "System deployment and integration phase"),
    OPERATION("Operation", "Operational use and monitoring phase"),
    DECOMMISSIONING("Decommissioning", "System retirement and data disposal phase");

    private final String displayName;
    private final String description;

    AILifecycleStage(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this stage is pre-production
     */
    public boolean isPreProduction() {
        return this == DESIGN || this == DEVELOPMENT;
    }

    /**
     * Check if this stage is production
     */
    public boolean isProduction() {
        return this == DEPLOYMENT || this == OPERATION;
    }

    /**
     * Get the next stage in the lifecycle
     */
    public AILifecycleStage getNextStage() {
        switch (this) {
            case DESIGN: return DEVELOPMENT;
            case DEVELOPMENT: return DEPLOYMENT;
            case DEPLOYMENT: return OPERATION;
            case OPERATION: return DECOMMISSIONING;
            case DECOMMISSIONING: return null;
            default: return null;
        }
    }

    /**
     * Get stage-specific risk factors
     */
    public String[] getStageSpecificRiskFactors() {
        switch (this) {
            case DESIGN:
                return new String[]{"Requirements definition", "Architecture decisions", "Data strategy"};
            case DEVELOPMENT:
                return new String[]{"Training data quality", "Model bias", "Security vulnerabilities"};
            case DEPLOYMENT:
                return new String[]{"Integration issues", "Performance degradation", "Access controls"};
            case OPERATION:
                return new String[]{"Model drift", "Data quality", "Adversarial attacks"};
            case DECOMMISSIONING:
                return new String[]{"Data retention", "Model archival", "Dependency management"};
            default:
                return new String[]{};
        }
    }
}
