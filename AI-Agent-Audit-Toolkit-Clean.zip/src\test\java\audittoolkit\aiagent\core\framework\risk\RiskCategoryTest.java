package audittoolkit.aiagent.core.framework.risk;

import audittoolkit.aiagent.core.framework.lifecycle.AILifecycleStage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for RiskCategory entity and related functionality.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
@DisplayName("Risk Category Tests")
class RiskCategoryTest {

    private RiskCategory riskCategory;

    @BeforeEach
    void setUp() {
        riskCategory = new RiskCategory(
            "TEST_RISK",
            "Test Risk Category",
            "A test risk category for unit testing",
            RiskSeverity.HIGH,
            RiskLikelihood.MEDIUM,
            RiskScope.APPLICATION,
            RiskTimeScale.IMMEDIATE
        );
    }

    @Nested
    @DisplayName("Risk Category Creation Tests")
    class CreationTests {

        @Test
        @DisplayName("Should create risk category with valid parameters")
        void shouldCreateRiskCategoryWithValidParameters() {
            assertNotNull(riskCategory);
            assertEquals("TEST_RISK", riskCategory.getCode());
            assertEquals("Test Risk Category", riskCategory.getName());
            assertEquals(RiskSeverity.HIGH, riskCategory.getSeverity());
            assertEquals(RiskLikelihood.MEDIUM, riskCategory.getLikelihood());
            assertEquals(RiskScope.APPLICATION, riskCategory.getScope());
            assertEquals(RiskTimeScale.IMMEDIATE, riskCategory.getTimeScale());
        }

        @Test
        @DisplayName("Should set default values correctly")
        void shouldSetDefaultValuesCorrectly() {
            assertFalse(riskCategory.getIsGAISpecific());
            assertTrue(riskCategory.getIsActive());
        }

        @Test
        @DisplayName("Should calculate risk score correctly")
        void shouldCalculateRiskScoreCorrectly() {
            double expectedScore = RiskSeverity.HIGH.getWeight() * RiskLikelihood.MEDIUM.getWeight();
            assertEquals(expectedScore, riskCategory.calculateRiskScore(), 0.001);
        }
    }

    @Nested
    @DisplayName("NIST GAI Risk Category Factory Tests")
    class FactoryTests {

        @Test
        @DisplayName("Should create CBRN risk category correctly")
        void shouldCreateCBRNRiskCategoryCorrectly() {
            RiskCategory cbrnRisk = RiskCategory.createCBRNRisk();
            
            assertEquals("CBRN_INFO", cbrnRisk.getCode());
            assertEquals("CBRN Information or Capabilities", cbrnRisk.getName());
            assertEquals(RiskSeverity.CRITICAL, cbrnRisk.getSeverity());
            assertEquals(RiskLikelihood.LOW, cbrnRisk.getLikelihood());
            assertEquals(RiskScope.ECOSYSTEM, cbrnRisk.getScope());
            assertEquals(RiskTimeScale.IMMEDIATE, cbrnRisk.getTimeScale());
        }

        @Test
        @DisplayName("Should create Confabulation risk category correctly")
        void shouldCreateConfabulationRiskCategoryCorrectly() {
            RiskCategory confabulationRisk = RiskCategory.createConfabulationRisk();
            
            assertEquals("CONFABULATION", confabulationRisk.getCode());
            assertEquals("Confabulation", confabulationRisk.getName());
            assertEquals(RiskSeverity.HIGH, confabulationRisk.getSeverity());
            assertEquals(RiskLikelihood.HIGH, confabulationRisk.getLikelihood());
            assertEquals(RiskScope.APPLICATION, confabulationRisk.getScope());
            assertEquals(RiskTimeScale.IMMEDIATE, confabulationRisk.getTimeScale());
        }

        @Test
        @DisplayName("Should create Dangerous Content risk category correctly")
        void shouldCreateDangerousContentRiskCategoryCorrectly() {
            RiskCategory dangerousContentRisk = RiskCategory.createDangerousContentRisk();
            
            assertEquals("DANGEROUS_CONTENT", dangerousContentRisk.getCode());
            assertEquals("Dangerous, Violent, or Hateful Content", dangerousContentRisk.getName());
            assertEquals(RiskSeverity.CRITICAL, dangerousContentRisk.getSeverity());
            assertEquals(RiskLikelihood.MEDIUM, dangerousContentRisk.getLikelihood());
            assertEquals(RiskScope.ECOSYSTEM, dangerousContentRisk.getScope());
            assertEquals(RiskTimeScale.IMMEDIATE, dangerousContentRisk.getTimeScale());
        }

        @Test
        @DisplayName("Should create Data Privacy risk category correctly")
        void shouldCreateDataPrivacyRiskCategoryCorrectly() {
            RiskCategory dataPrivacyRisk = RiskCategory.createDataPrivacyRisk();
            
            assertEquals("DATA_PRIVACY", dataPrivacyRisk.getCode());
            assertEquals("Data Privacy", dataPrivacyRisk.getName());
            assertEquals(RiskSeverity.HIGH, dataPrivacyRisk.getSeverity());
            assertEquals(RiskLikelihood.MEDIUM, dataPrivacyRisk.getLikelihood());
            assertEquals(RiskScope.APPLICATION, dataPrivacyRisk.getScope());
            assertEquals(RiskTimeScale.EXTENDED, dataPrivacyRisk.getTimeScale());
        }

        @Test
        @DisplayName("Should create Environmental risk category correctly")
        void shouldCreateEnvironmentalRiskCategoryCorrectly() {
            RiskCategory environmentalRisk = RiskCategory.createEnvironmentalRisk();
            
            assertEquals("ENVIRONMENTAL", environmentalRisk.getCode());
            assertEquals("Environmental Impacts", environmentalRisk.getName());
            assertEquals(RiskSeverity.MEDIUM, environmentalRisk.getSeverity());
            assertEquals(RiskLikelihood.HIGH, environmentalRisk.getLikelihood());
            assertEquals(RiskScope.ECOSYSTEM, environmentalRisk.getScope());
            assertEquals(RiskTimeScale.EXTENDED, environmentalRisk.getTimeScale());
        }

        @Test
        @DisplayName("Should create Harmful Bias risk category correctly")
        void shouldCreateHarmfulBiasRiskCategoryCorrectly() {
            RiskCategory harmfulBiasRisk = RiskCategory.createHarmfulBiasRisk();
            
            assertEquals("HARMFUL_BIAS", harmfulBiasRisk.getCode());
            assertEquals("Harmful Bias or Homogenization", harmfulBiasRisk.getName());
            assertEquals(RiskSeverity.HIGH, harmfulBiasRisk.getSeverity());
            assertEquals(RiskLikelihood.HIGH, harmfulBiasRisk.getLikelihood());
            assertEquals(RiskScope.APPLICATION, harmfulBiasRisk.getScope());
            assertEquals(RiskTimeScale.EXTENDED, harmfulBiasRisk.getTimeScale());
        }
    }

    @Nested
    @DisplayName("Risk Category Lifecycle Tests")
    class LifecycleTests {

        @Test
        @DisplayName("Should handle applicable stages correctly")
        void shouldHandleApplicableStagesCorrectly() {
            Set<AILifecycleStage> stages = Set.of(
                AILifecycleStage.DEVELOPMENT,
                AILifecycleStage.DEPLOYMENT,
                AILifecycleStage.OPERATION
            );
            
            riskCategory.setApplicableStages(stages);
            
            assertEquals(3, riskCategory.getApplicableStages().size());
            assertTrue(riskCategory.getApplicableStages().contains(AILifecycleStage.DEVELOPMENT));
            assertTrue(riskCategory.getApplicableStages().contains(AILifecycleStage.DEPLOYMENT));
            assertTrue(riskCategory.getApplicableStages().contains(AILifecycleStage.OPERATION));
        }

        @Test
        @DisplayName("Should handle affected characteristics correctly")
        void shouldHandleAffectedCharacteristicsCorrectly() {
            Set<TrustworthyAICharacteristic> characteristics = Set.of(
                TrustworthyAICharacteristic.SAFE,
                TrustworthyAICharacteristic.SECURE_RESILIENT,
                TrustworthyAICharacteristic.FAIR_BIAS_MANAGED
            );
            
            riskCategory.setAffectedCharacteristics(characteristics);
            
            assertEquals(3, riskCategory.getAffectedCharacteristics().size());
            assertTrue(riskCategory.getAffectedCharacteristics().contains(TrustworthyAICharacteristic.SAFE));
            assertTrue(riskCategory.getAffectedCharacteristics().contains(TrustworthyAICharacteristic.SECURE_RESILIENT));
            assertTrue(riskCategory.getAffectedCharacteristics().contains(TrustworthyAICharacteristic.FAIR_BIAS_MANAGED));
        }
    }

    @Nested
    @DisplayName("Risk Score Calculation Tests")
    class RiskScoreTests {

        @Test
        @DisplayName("Should calculate maximum risk score for critical/very high")
        void shouldCalculateMaximumRiskScore() {
            riskCategory.setSeverity(RiskSeverity.CRITICAL);
            riskCategory.setLikelihood(RiskLikelihood.VERY_HIGH);
            
            double expectedScore = 4.0 * 0.9; // CRITICAL * VERY_HIGH
            assertEquals(expectedScore, riskCategory.calculateRiskScore(), 0.001);
        }

        @Test
        @DisplayName("Should calculate minimum risk score for low/very low")
        void shouldCalculateMinimumRiskScore() {
            riskCategory.setSeverity(RiskSeverity.LOW);
            riskCategory.setLikelihood(RiskLikelihood.VERY_LOW);
            
            double expectedScore = 1.0 * 0.1; // LOW * VERY_LOW
            assertEquals(expectedScore, riskCategory.calculateRiskScore(), 0.001);
        }

        @Test
        @DisplayName("Should calculate medium risk score correctly")
        void shouldCalculateMediumRiskScore() {
            riskCategory.setSeverity(RiskSeverity.MEDIUM);
            riskCategory.setLikelihood(RiskLikelihood.MEDIUM);
            
            double expectedScore = 2.0 * 0.5; // MEDIUM * MEDIUM
            assertEquals(expectedScore, riskCategory.calculateRiskScore(), 0.001);
        }
    }

    @Nested
    @DisplayName("Risk Category Validation Tests")
    class ValidationTests {

        @Test
        @DisplayName("Should handle GAI specific flag correctly")
        void shouldHandleGAISpecificFlagCorrectly() {
            assertFalse(riskCategory.getIsGAISpecific());
            
            riskCategory.setIsGAISpecific(true);
            assertTrue(riskCategory.getIsGAISpecific());
        }

        @Test
        @DisplayName("Should handle active flag correctly")
        void shouldHandleActiveFlagCorrectly() {
            assertTrue(riskCategory.getIsActive());
            
            riskCategory.setIsActive(false);
            assertFalse(riskCategory.getIsActive());
        }

        @Test
        @DisplayName("Should generate meaningful toString")
        void shouldGenerateMeaningfulToString() {
            String toString = riskCategory.toString();
            
            assertTrue(toString.contains("TEST_RISK"));
            assertTrue(toString.contains("Test Risk Category"));
            assertTrue(toString.contains("HIGH"));
            assertTrue(toString.contains("MEDIUM"));
            assertTrue(toString.contains("APPLICATION"));
            assertTrue(toString.contains("IMMEDIATE"));
        }
    }

    @Nested
    @DisplayName("Risk Category Comparison Tests")
    class ComparisonTests {

        @Test
        @DisplayName("Should compare risk scores correctly")
        void shouldCompareRiskScoresCorrectly() {
            RiskCategory highRisk = RiskCategory.createCBRNRisk(); // CRITICAL/LOW
            RiskCategory mediumRisk = RiskCategory.createDataPrivacyRisk(); // HIGH/MEDIUM
            RiskCategory lowRisk = RiskCategory.createEnvironmentalRisk(); // MEDIUM/HIGH
            
            double highScore = highRisk.calculateRiskScore();
            double mediumScore = mediumRisk.calculateRiskScore();
            double lowScore = lowRisk.calculateRiskScore();
            
            // CRITICAL/LOW (4.0 * 0.3 = 1.2) should be less than HIGH/MEDIUM (3.0 * 0.5 = 1.5)
            assertTrue(highScore < mediumScore);
            
            // HIGH/MEDIUM (3.0 * 0.5 = 1.5) should be greater than MEDIUM/HIGH (2.0 * 0.7 = 1.4)
            assertTrue(mediumScore > lowScore);
        }
    }
}
