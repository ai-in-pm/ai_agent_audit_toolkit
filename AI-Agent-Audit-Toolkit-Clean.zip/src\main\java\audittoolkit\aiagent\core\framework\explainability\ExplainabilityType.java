package audittoolkit.aiagent.core.framework.explainability;

/**
 * Explainability types based on ISACA AI Audit Toolkit six dimensions.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum ExplainabilityType {
    
    RATIONALE("Rationale", "Logical reasoning behind AI decisions"),
    RESPONSIBILITY("Responsibility", "Accountability framework within AI operations"),
    DATA("Data", "Origin, nature, and processing of data used by AI systems"),
    FAIRNESS("Fairness", "How AI systems ensure fairness and avoid bias"),
    SAFETY_PERFORMANCE("Safety & Performance", "Measures to ensure safety and optimal performance"),
    IMPACT("Impact", "Broader implications including societal, ethical, and regulatory impacts");

    private final String displayName;
    private final String description;

    ExplainabilityType(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Check if this type is related to technical aspects
     */
    public boolean isTechnical() {
        return this == RATIONALE || this == DATA || this == SAFETY_PERFORMANCE;
    }

    /**
     * Check if this type is related to governance aspects
     */
    public boolean isGovernance() {
        return this == RESPONSIBILITY || this == FAIRNESS || this == IMPACT;
    }

    /**
     * Get assessment priority level
     */
    public int getAssessmentPriority() {
        switch (this) {
            case SAFETY_PERFORMANCE: return 1; // Highest priority
            case FAIRNESS: return 2;
            case RESPONSIBILITY: return 3;
            case DATA: return 4;
            case RATIONALE: return 5;
            case IMPACT: return 6; // Lowest priority
            default: return 5;
        }
    }

    /**
     * Get typical stakeholders involved in this dimension
     */
    public String[] getTypicalStakeholders() {
        switch (this) {
            case RATIONALE:
                return new String[]{"Data Scientists", "ML Engineers", "Technical Auditors"};
            case RESPONSIBILITY:
                return new String[]{"AI Governance Team", "Legal Team", "Compliance Officers"};
            case DATA:
                return new String[]{"Data Engineers", "Privacy Officers", "Data Governance Team"};
            case FAIRNESS:
                return new String[]{"Ethics Committee", "Bias Testing Team", "Legal Team"};
            case SAFETY_PERFORMANCE:
                return new String[]{"QA Engineers", "Safety Officers", "Performance Team"};
            case IMPACT:
                return new String[]{"Sustainability Team", "Regulatory Affairs", "Ethics Committee"};
            default:
                return new String[]{};
        }
    }

    /**
     * Get recommended assessment frequency in months
     */
    public int getRecommendedAssessmentFrequency() {
        switch (this) {
            case SAFETY_PERFORMANCE: return 1; // Monthly
            case FAIRNESS: return 3; // Quarterly
            case DATA: return 3; // Quarterly
            case RESPONSIBILITY: return 6; // Semi-annually
            case RATIONALE: return 6; // Semi-annually
            case IMPACT: return 12; // Annually
            default: return 6;
        }
    }
}
