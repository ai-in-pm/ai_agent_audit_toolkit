package audittoolkit.aiagent.core.framework.explainability;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Represents an explainability dimension based on ISACA AI Audit Toolkit.
 * Six dimensions: Rationale, Responsibility, Data, Fairness, Safety & Performance, and Impact.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
@Entity
@Table(name = "explainability_dimensions")
public class ExplainabilityDimension {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(unique = true, nullable = false)
    private String code;

    @NotBlank
    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @NotNull
    private ExplainabilityType type;

    @ElementCollection
    @CollectionTable(name = "explainability_evidence_types")
    private List<String> evidenceTypes;

    @ElementCollection
    @CollectionTable(name = "explainability_assessment_types")
    private List<String> assessmentTypes;

    @ElementCollection
    @CollectionTable(name = "explainability_assessment_methods")
    private List<String> assessmentMethods;

    @Column(nullable = false)
    private Boolean isActive = true;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public ExplainabilityDimension() {}

    public ExplainabilityDimension(String code, String name, String description, ExplainabilityType type) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.type = type;
    }

    // Factory methods for the six ISACA explainability dimensions
    public static ExplainabilityDimension createRationaleDimension() {
        ExplainabilityDimension dimension = new ExplainabilityDimension(
            "RATIONALE",
            "Rationale Explanation",
            "Focuses on the logical reasoning behind AI decisions; aims to make the decision-making process of AI systems transparent and comprehensible",
            ExplainabilityType.RATIONALE
        );
        
        dimension.setEvidenceTypes(List.of(
            "Logic maps",
            "Decision trees", 
            "Documentation explaining the AI model's reasoning"
        ));
        
        dimension.setAssessmentTypes(List.of(
            "Evaluation of the clarity and logic of the explanations provided by AI models"
        ));
        
        dimension.setAssessmentMethods(List.of(
            "Reviewing the logical coherence and transparency of decision-making processes in AI models"
        ));
        
        return dimension;
    }

    public static ExplainabilityDimension createResponsibilityDimension() {
        ExplainabilityDimension dimension = new ExplainabilityDimension(
            "RESPONSIBILITY",
            "Responsibility Explanation",
            "Delineates the accountability framework within AI operations, clarifying who or what is responsible for specific decisions and actions",
            ExplainabilityType.RESPONSIBILITY
        );
        
        dimension.setEvidenceTypes(List.of(
            "Accountability matrices",
            "Role definitions",
            "Documentation of decision ownership"
        ));
        
        dimension.setAssessmentTypes(List.of(
            "Assessment of clear lines of accountability and responsibility in AI system operations"
        ));
        
        dimension.setAssessmentMethods(List.of(
            "Analyzing documentation and system design to ensure clear assignment of responsibilities"
        ));
        
        return dimension;
    }

    public static ExplainabilityDimension createDataDimension() {
        ExplainabilityDimension dimension = new ExplainabilityDimension(
            "DATA",
            "Data Explanation",
            "Focuses on the origin, nature, and processing of data used by AI systems",
            ExplainabilityType.DATA
        );
        
        dimension.setEvidenceTypes(List.of(
            "Data lineage records",
            "Processing logs",
            "Data source documentation"
        ));
        
        dimension.setAssessmentTypes(List.of(
            "Verification of the authenticity, relevance, and integrity of the data used"
        ));
        
        dimension.setAssessmentMethods(List.of(
            "Inspecting data handling practices, source validation, and data integrity checks"
        ));
        
        return dimension;
    }

    public static ExplainabilityDimension createFairnessDimension() {
        ExplainabilityDimension dimension = new ExplainabilityDimension(
            "FAIRNESS",
            "Fairness Explanation",
            "Addresses how AI systems ensure fairness and avoid bias in their operations",
            ExplainabilityType.FAIRNESS
        );
        
        dimension.setEvidenceTypes(List.of(
            "Fairness metrics reports",
            "Bias detection analyses",
            "Corrective action plans"
        ));
        
        dimension.setAssessmentTypes(List.of(
            "Assessment of mechanisms and practices in place to detect and mitigate bias"
        ));
        
        dimension.setAssessmentMethods(List.of(
            "Evaluating the effectiveness of bias detection tools and the implementation of fairness guidelines"
        ));
        
        return dimension;
    }

    public static ExplainabilityDimension createSafetyPerformanceDimension() {
        ExplainabilityDimension dimension = new ExplainabilityDimension(
            "SAFETY_PERFORMANCE",
            "Safety & Performance Explanation",
            "Elucidates the measures taken to ensure the safety and optimal performance of AI systems",
            ExplainabilityType.SAFETY_PERFORMANCE
        );
        
        dimension.setEvidenceTypes(List.of(
            "Safety protocols",
            "Performance testing results",
            "Maintenance records"
        ));
        
        dimension.setAssessmentTypes(List.of(
            "Evaluation of the system's safety features and performance standards"
        ));
        
        dimension.setAssessmentMethods(List.of(
            "Reviewing safety compliance documents and performance benchmarking results"
        ));
        
        return dimension;
    }

    public static ExplainabilityDimension createImpactDimension() {
        ExplainabilityDimension dimension = new ExplainabilityDimension(
            "IMPACT",
            "Impact Explanation",
            "Explores the broader implications of AI systems, including their societal, ethical, environmental, and regulatory impacts",
            ExplainabilityType.IMPACT
        );
        
        dimension.setEvidenceTypes(List.of(
            "Impact assessment reports",
            "Ethical considerations documentation",
            "Sustainability analyses",
            "Compliance and regulatory impact assessment reports"
        ));
        
        dimension.setAssessmentTypes(List.of(
            "Analysis of the AI system's impact on users, society, and the environment",
            "Analysis of the impact of legislation, regulations, and frameworks"
        ));
        
        dimension.setAssessmentMethods(List.of(
            "Examining comprehensive impact assessments and sustainability strategies",
            "Identifying relevant laws and regulations, evaluating regulatory impact, and assessing level of compliance"
        ));
        
        return dimension;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public ExplainabilityType getType() { return type; }
    public void setType(ExplainabilityType type) { this.type = type; }

    public List<String> getEvidenceTypes() { return evidenceTypes; }
    public void setEvidenceTypes(List<String> evidenceTypes) { this.evidenceTypes = evidenceTypes; }

    public List<String> getAssessmentTypes() { return assessmentTypes; }
    public void setAssessmentTypes(List<String> assessmentTypes) { this.assessmentTypes = assessmentTypes; }

    public List<String> getAssessmentMethods() { return assessmentMethods; }
    public void setAssessmentMethods(List<String> assessmentMethods) { this.assessmentMethods = assessmentMethods; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    @Override
    public String toString() {
        return "ExplainabilityDimension{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", type=" + type +
                '}';
    }
}
