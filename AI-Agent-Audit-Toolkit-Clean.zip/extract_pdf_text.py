#!/usr/bin/env python3
"""
PDF Text Extraction Script for AI Audit Toolkit Analysis
"""

import sys
import os

def extract_with_pypdf2(pdf_path):
    """Extract text using PyPDF2"""
    try:
        import PyPDF2
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
        return text
    except ImportError:
        return None
    except Exception as e:
        print(f"Error with PyPDF2: {e}")
        return None

def extract_with_pdfplumber(pdf_path):
    """Extract text using pdfplumber"""
    try:
        import pdfplumber
        text = ""
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
        return text
    except ImportError:
        return None
    except Exception as e:
        print(f"Error with pdfplumber: {e}")
        return None

def extract_with_pymupdf(pdf_path):
    """Extract text using PyMuPDF (fitz)"""
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(pdf_path)
        text = ""
        for page in doc:
            text += page.get_text() + "\n"
        doc.close()
        return text
    except ImportError:
        return None
    except Exception as e:
        print(f"Error with PyMuPDF: {e}")
        return None

def extract_pdf_text(pdf_path):
    """Try multiple PDF extraction methods"""
    print(f"Extracting text from: {pdf_path}")
    
    # Try different extraction methods
    methods = [
        ("PyMuPDF", extract_with_pymupdf),
        ("pdfplumber", extract_with_pdfplumber),
        ("PyPDF2", extract_with_pypdf2)
    ]
    
    for method_name, method_func in methods:
        print(f"Trying {method_name}...")
        text = method_func(pdf_path)
        if text:
            print(f"Successfully extracted text using {method_name}")
            return text
        else:
            print(f"{method_name} failed or not available")
    
    print("All extraction methods failed")
    return None

def main():
    if len(sys.argv) != 2:
        print("Usage: python extract_pdf_text.py <pdf_path>")
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    if not os.path.exists(pdf_path):
        print(f"File not found: {pdf_path}")
        sys.exit(1)
    
    text = extract_pdf_text(pdf_path)
    if text:
        # Save to text file
        output_path = pdf_path.replace('.pdf', '_extracted.txt')
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(text)
        print(f"Text saved to: {output_path}")
        
        # Print first 2000 characters for preview
        print("\n" + "="*50)
        print("PREVIEW (first 2000 characters):")
        print("="*50)
        print(text[:2000])
        if len(text) > 2000:
            print("\n... (truncated)")
    else:
        print("Failed to extract text from PDF")

if __name__ == "__main__":
    main()
