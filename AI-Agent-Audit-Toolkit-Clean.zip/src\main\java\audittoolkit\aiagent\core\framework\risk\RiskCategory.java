package audittoolkit.aiagent.core.framework.risk;

import audittoolkit.aiagent.core.framework.lifecycle.AILifecycleStage;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Set;

/**
 * Represents a risk category in the AI Risk Management Framework.
 * Based on NIST AI 600-1 GAI Risk Categories.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
@Entity
@Table(name = "risk_categories")
public class RiskCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(unique = true, nullable = false)
    private String code;

    @NotBlank
    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @NotNull
    private RiskSeverity severity;

    @Enumerated(EnumType.STRING)
    @NotNull
    private RiskLikelihood likelihood;

    @Enumerated(EnumType.STRING)
    @NotNull
    private RiskScope scope;

    @Enumerated(EnumType.STRING)
    @NotNull
    private RiskTimeScale timeScale;

    @ElementCollection(targetClass = AILifecycleStage.class)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "risk_category_lifecycle_stages")
    private Set<AILifecycleStage> applicableStages;

    @ElementCollection(targetClass = TrustworthyAICharacteristic.class)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "risk_category_ai_characteristics")
    private Set<TrustworthyAICharacteristic> affectedCharacteristics;

    @Column(nullable = false)
    private Boolean isGAISpecific = false;

    @Column(nullable = false)
    private Boolean isActive = true;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public RiskCategory() {}

    public RiskCategory(String code, String name, String description, 
                       RiskSeverity severity, RiskLikelihood likelihood,
                       RiskScope scope, RiskTimeScale timeScale) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.severity = severity;
        this.likelihood = likelihood;
        this.scope = scope;
        this.timeScale = timeScale;
    }

    // NIST GAI Risk Categories Factory Methods
    public static RiskCategory createCBRNRisk() {
        return new RiskCategory(
            "CBRN_INFO",
            "CBRN Information or Capabilities",
            "Eased access to or synthesis of materially nefarious information or design capabilities related to chemical, biological, radiological, or nuclear (CBRN) weapons or other dangerous materials or agents.",
            RiskSeverity.CRITICAL,
            RiskLikelihood.LOW,
            RiskScope.ECOSYSTEM,
            RiskTimeScale.IMMEDIATE
        );
    }

    public static RiskCategory createConfabulationRisk() {
        return new RiskCategory(
            "CONFABULATION",
            "Confabulation",
            "The production of confidently stated but erroneous or false content (known colloquially as 'hallucinations' or 'fabrications') by which users may be misled or deceived.",
            RiskSeverity.HIGH,
            RiskLikelihood.HIGH,
            RiskScope.APPLICATION,
            RiskTimeScale.IMMEDIATE
        );
    }

    public static RiskCategory createDangerousContentRisk() {
        return new RiskCategory(
            "DANGEROUS_CONTENT",
            "Dangerous, Violent, or Hateful Content",
            "Eased production of and access to violent, inciting, radicalizing, or threatening content as well as recommendations to carry out self-harm or conduct illegal activities.",
            RiskSeverity.CRITICAL,
            RiskLikelihood.MEDIUM,
            RiskScope.ECOSYSTEM,
            RiskTimeScale.IMMEDIATE
        );
    }

    public static RiskCategory createDataPrivacyRisk() {
        return new RiskCategory(
            "DATA_PRIVACY",
            "Data Privacy",
            "Impacts due to leakage and unauthorized use, disclosure, or de-anonymization of biometric, health, location, or other personally identifiable information or sensitive data.",
            RiskSeverity.HIGH,
            RiskLikelihood.MEDIUM,
            RiskScope.APPLICATION,
            RiskTimeScale.EXTENDED
        );
    }

    public static RiskCategory createEnvironmentalRisk() {
        return new RiskCategory(
            "ENVIRONMENTAL",
            "Environmental Impacts",
            "Impacts due to high compute resource utilization in training or operating GAI models, and related outcomes that may adversely impact ecosystems.",
            RiskSeverity.MEDIUM,
            RiskLikelihood.HIGH,
            RiskScope.ECOSYSTEM,
            RiskTimeScale.EXTENDED
        );
    }

    public static RiskCategory createHarmfulBiasRisk() {
        return new RiskCategory(
            "HARMFUL_BIAS",
            "Harmful Bias or Homogenization",
            "Amplification and exacerbation of historical, societal, and systemic biases; performance disparities between sub-groups or languages that result in discrimination or incorrect presumptions.",
            RiskSeverity.HIGH,
            RiskLikelihood.HIGH,
            RiskScope.APPLICATION,
            RiskTimeScale.EXTENDED
        );
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public RiskSeverity getSeverity() { return severity; }
    public void setSeverity(RiskSeverity severity) { this.severity = severity; }

    public RiskLikelihood getLikelihood() { return likelihood; }
    public void setLikelihood(RiskLikelihood likelihood) { this.likelihood = likelihood; }

    public RiskScope getScope() { return scope; }
    public void setScope(RiskScope scope) { this.scope = scope; }

    public RiskTimeScale getTimeScale() { return timeScale; }
    public void setTimeScale(RiskTimeScale timeScale) { this.timeScale = timeScale; }

    public Set<AILifecycleStage> getApplicableStages() { return applicableStages; }
    public void setApplicableStages(Set<AILifecycleStage> applicableStages) { this.applicableStages = applicableStages; }

    public Set<TrustworthyAICharacteristic> getAffectedCharacteristics() { return affectedCharacteristics; }
    public void setAffectedCharacteristics(Set<TrustworthyAICharacteristic> affectedCharacteristics) { this.affectedCharacteristics = affectedCharacteristics; }

    public Boolean getIsGAISpecific() { return isGAISpecific; }
    public void setIsGAISpecific(Boolean isGAISpecific) { this.isGAISpecific = isGAISpecific; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    /**
     * Calculate risk score based on severity and likelihood
     */
    public double calculateRiskScore() {
        return severity.getWeight() * likelihood.getWeight();
    }

    @Override
    public String toString() {
        return "RiskCategory{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", severity=" + severity +
                ", likelihood=" + likelihood +
                ", scope=" + scope +
                ", timeScale=" + timeScale +
                '}';
    }
}
