package audittoolkit.aiagent.core.ai_agent_audit_toolkit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiAgentAuditToolkitApplicationTests {

    @Test
    void contextLoads() {
    }

}
