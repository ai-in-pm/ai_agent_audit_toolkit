# AI Agent Audit Toolkit - Implementation Guide

**© 2024 Darrell Mesa. All rights reserved.**  
**Owner**: Darrell Mesa (darrell.mesa@pm-ss.org)  
**License**: Proprietary - Not for commercial use

## Overview

This implementation guide provides comprehensive instructions for deploying and using the AI Agent Audit Toolkit, which integrates ISACA AI Audit Toolkit and NIST AI Risk Management Framework methodologies.

## Architecture Overview

### Core Components

1. **Framework Module** (`src/main/java/audittoolkit/aiagent/core/framework/`)
   - **Risk Management**: NIST GAI risk categories and assessment
   - **Control Framework**: ISACA control families, categories, and controls
   - **Explainability Engine**: Six-dimension assessment framework
   - **Lifecycle Management**: AI system lifecycle tracking

2. **Assessment Engine** (`src/main/java/audittoolkit/aiagent/core/assessment/`)
   - Multi-methodology assessment support
   - Automated evidence collection
   - Dynamic test execution
   - Compliance evaluation

3. **API Layer** (`src/main/java/audittoolkit/aiagent/core/api/`)
   - RESTful API endpoints
   - Request/Response DTOs
   - Authentication and authorization

4. **Database Layer** (`src/main/resources/database/`)
   - PostgreSQL schema with Flyway migrations
   - Comprehensive data model for frameworks

## Prerequisites

### System Requirements
- Java 17 or higher
- Maven 3.6+ or Gradle 7+
- PostgreSQL 12+
- MongoDB 4.4+ (optional, for document storage)
- Redis 6+ (optional, for caching)

### Development Environment
- IDE with Spring Boot support (IntelliJ IDEA, Eclipse, VS Code)
- Git for version control
- Docker (optional, for containerized deployment)

## Installation and Setup

### 1. Database Setup

#### PostgreSQL Setup
```sql
-- Create database and user
CREATE DATABASE ai_audit_toolkit;
CREATE USER ai_audit_user WITH PASSWORD 'ai_audit_pass';
GRANT ALL PRIVILEGES ON DATABASE ai_audit_toolkit TO ai_audit_user;
```

#### MongoDB Setup (Optional)
```bash
# Start MongoDB
mongod --dbpath /path/to/data/db

# Create database (will be created automatically on first use)
# Database name: ai_audit_toolkit_docs
```

#### Redis Setup (Optional)
```bash
# Start Redis server
redis-server

# Test connection
redis-cli ping
```

### 2. Application Configuration

Update `src/main/resources/application.yml` with your database credentials:

```yaml
spring:
  datasource:
    primary:
      url: jdbc:postgresql://localhost:5432/ai_audit_toolkit
      username: your_db_username
      password: your_db_password
```

### 3. Build and Run

#### Using Gradle
```bash
# Build the application
./gradlew build

# Run the application
./gradlew bootRun

# Run tests
./gradlew test
```

#### Using Maven (if converted)
```bash
# Build the application
mvn clean install

# Run the application
mvn spring-boot:run

# Run tests
mvn test
```

### 4. Verify Installation

1. **Application Health**: http://localhost:8080/actuator/health
2. **API Documentation**: http://localhost:8080/swagger-ui.html
3. **Database**: Check that tables are created via Flyway migrations

## Framework Implementation

### NIST AI Risk Management Framework

The toolkit implements 12 primary GAI risk categories:

1. **CBRN Information or Capabilities** (`CBRN_INFO`)
2. **Confabulation** (`CONFABULATION`)
3. **Dangerous, Violent, or Hateful Content** (`DANGEROUS_CONTENT`)
4. **Data Privacy** (`DATA_PRIVACY`)
5. **Environmental Impacts** (`ENVIRONMENTAL`)
6. **Harmful Bias or Homogenization** (`HARMFUL_BIAS`)
7. **Human-AI Configuration** (`HUMAN_AI_CONFIG`)
8. **Information Integrity** (`INFO_INTEGRITY`)
9. **Information Security** (`INFO_SECURITY`)
10. **Intellectual Property** (`INTELLECTUAL_PROPERTY`)
11. **Obscene, Degrading, and/or Abusive Content** (`OBSCENE_CONTENT`)
12. **Value Chain and Component Integration** (`VALUE_CHAIN`)

### ISACA AI Audit Toolkit

The toolkit implements 20+ control families:

1. **Adversarial Defense & Robustness** (`ADR`)
2. **AI Bias Mitigation & Fairness** (`BMF`)
3. **AI Data Privacy & Rights** (`DPR`)
4. **AI Ecosystem Security** (`ESS`)
5. **AI Life Cycle Management** (`LCM`)
6. **AI Model Governance** (`MGV`)
7. **AI Operations** (`OPS`)
8. **Asset Management** (`ASM`)
9. **Audit & Compliance** (`AUD`)
10. **Business Continuity** (`BCM`)

### Explainability Dimensions

Six dimensions based on ICO and Alan Turing Institute framework:

1. **Rationale** - Logical reasoning behind AI decisions
2. **Responsibility** - Accountability framework
3. **Data** - Origin and processing of data
4. **Fairness** - Bias detection and mitigation
5. **Safety & Performance** - Safety measures and performance
6. **Impact** - Broader implications and regulatory compliance

## API Usage

### Authentication

The API uses JWT-based authentication. Configure your OAuth2 provider in `application.yml`:

```yaml
spring:
  security:
    oauth2:
      resourceserver:
        jwt:
          issuer-uri: your-oauth2-issuer
          jwk-set-uri: your-jwk-set-uri
```

### Core API Endpoints

#### 1. Execute Assessment
```http
POST /api/v1/assessments/execute
Content-Type: application/json
Authorization: Bearer {jwt-token}

{
  "systemName": "My AI System",
  "systemDescription": "Description of the AI system",
  "methodology": "HYBRID",
  "explainabilityDimensions": ["RATIONALE", "FAIRNESS", "SAFETY_PERFORMANCE"],
  "lifecycleStages": ["DEVELOPMENT", "DEPLOYMENT"],
  "controlFamilyCodes": ["ADR", "BMF", "DPR"],
  "riskCategoryCodes": ["CONFABULATION", "HARMFUL_BIAS", "DATA_PRIVACY"],
  "priority": "HIGH"
}
```

#### 2. Get Assessment Results
```http
GET /api/v1/assessments/{assessmentId}
Authorization: Bearer {jwt-token}
```

#### 3. List Assessments
```http
GET /api/v1/assessments?page=0&size=20&status=COMPLETED
Authorization: Bearer {jwt-token}
```

#### 4. Download Assessment Report
```http
GET /api/v1/assessments/{assessmentId}/download?format=PDF
Authorization: Bearer {jwt-token}
```

## Development Guidelines

### Code Structure

```
src/main/java/audittoolkit/aiagent/core/
├── framework/                 # Core framework entities
│   ├── risk/                 # Risk management
│   ├── controls/             # Control framework
│   ├── explainability/       # Explainability dimensions
│   └── lifecycle/            # AI lifecycle management
├── assessment/               # Assessment engine
│   ├── engine/              # Core assessment logic
│   ├── methodologies/       # Assessment methodologies
│   ├── evidence/            # Evidence collection
│   └── reporting/           # Report generation
├── api/                     # REST API layer
│   ├── controllers/         # API controllers
│   ├── dto/                # Data transfer objects
│   └── security/           # Security configuration
└── ai_agent_audit_toolkit/ # Main application
```

### Adding New Risk Categories

1. Create factory method in `RiskCategory.java`:
```java
public static RiskCategory createNewRisk() {
    return new RiskCategory(
        "NEW_RISK",
        "New Risk Category",
        "Description of the new risk",
        RiskSeverity.HIGH,
        RiskLikelihood.MEDIUM,
        RiskScope.APPLICATION,
        RiskTimeScale.IMMEDIATE
    );
}
```

2. Add to database migration script
3. Update API documentation

### Adding New Control Families

1. Create factory method in `ControlFamily.java`:
```java
public static ControlFamily createNewControlFamily() {
    return new ControlFamily(
        "NCF",
        "New Control Family",
        "Description of the new control family",
        ControlPriority.HIGH,
        ControlDomain.SECURITY
    );
}
```

2. Add control categories and controls
3. Update database migration script

### Testing

#### Unit Tests
```bash
# Run all tests
./gradlew test

# Run specific test class
./gradlew test --tests RiskCategoryTest

# Run tests with coverage
./gradlew test jacocoTestReport
```

#### Integration Tests
```bash
# Run integration tests
./gradlew integrationTest
```

## Deployment

### Production Configuration

1. **Database Configuration**
   - Use connection pooling
   - Configure SSL connections
   - Set up database monitoring

2. **Security Configuration**
   - Configure OAuth2/JWT properly
   - Set up HTTPS
   - Configure CORS appropriately

3. **Monitoring Configuration**
   - Enable Prometheus metrics
   - Configure logging levels
   - Set up health checks

### Docker Deployment

```dockerfile
FROM openjdk:17-jre-slim

COPY build/libs/ai-agent-audit-toolkit-*.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "/app.jar"]
```

### Environment Variables

```bash
# Database
DB_USERNAME=ai_audit_user
DB_PASSWORD=secure_password
DB_URL=jdbc:postgresql://db:5432/ai_audit_toolkit

# Security
JWT_ISSUER_URI=https://your-auth-provider.com
JWT_JWK_SET_URI=https://your-auth-provider.com/.well-known/jwks.json

# Monitoring
MANAGEMENT_ENDPOINTS_WEB_EXPOSURE_INCLUDE=health,info,metrics,prometheus
```

## Troubleshooting

### Common Issues

1. **Database Connection Issues**
   - Verify PostgreSQL is running
   - Check connection credentials
   - Ensure database exists

2. **Authentication Issues**
   - Verify JWT configuration
   - Check OAuth2 provider settings
   - Validate token format

3. **Performance Issues**
   - Check database indexes
   - Monitor connection pool
   - Review query performance

### Logging

Enable debug logging for troubleshooting:

```yaml
logging:
  level:
    audittoolkit.aiagent.core: DEBUG
    org.springframework.security: DEBUG
    org.hibernate.SQL: DEBUG
```

## Support and Contact

For technical support or questions:
- **Email**: darrell.mesa@pm-ss.org
- **Project Owner**: Darrell Mesa

## License

This software is proprietary and not for commercial use. All rights reserved by Darrell Mesa.
