-- AI Agent Audit Toolkit Database Schema
-- © 2024 Darrell Mesa. All rights reserved.
-- Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
-- Not for commercial use.

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Risk Categories Table
CREATE TABLE risk_categories (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    likelihood VARCHAR(20) NOT NULL CHECK (likelihood IN ('VERY_LOW', 'LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH')),
    scope VARCHAR(20) NOT NULL CHECK (scope IN ('MODEL', 'APPLICATION', 'ECOSYSTEM')),
    time_scale VARCHAR(20) NOT NULL CHECK (time_scale IN ('IMMEDIATE', 'SHORT_TERM', 'MEDIUM_TERM', 'EXTENDED')),
    is_gai_specific BOOLEAN NOT NULL DEFAULT FALSE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Risk Category Lifecycle Stages Junction Table
CREATE TABLE risk_category_lifecycle_stages (
    risk_category_id BIGINT NOT NULL REFERENCES risk_categories(id) ON DELETE CASCADE,
    lifecycle_stages VARCHAR(20) NOT NULL CHECK (lifecycle_stages IN ('DESIGN', 'DEVELOPMENT', 'DEPLOYMENT', 'OPERATION', 'DECOMMISSIONING')),
    PRIMARY KEY (risk_category_id, lifecycle_stages)
);

-- Risk Category AI Characteristics Junction Table
CREATE TABLE risk_category_ai_characteristics (
    risk_category_id BIGINT NOT NULL REFERENCES risk_categories(id) ON DELETE CASCADE,
    ai_characteristics VARCHAR(50) NOT NULL CHECK (ai_characteristics IN (
        'ACCOUNTABLE_TRANSPARENT', 'EXPLAINABLE_INTERPRETABLE', 'FAIR_BIAS_MANAGED',
        'PRIVACY_ENHANCED', 'SAFE', 'SECURE_RESILIENT', 'VALID_RELIABLE'
    )),
    PRIMARY KEY (risk_category_id, ai_characteristics)
);

-- Control Families Table
CREATE TABLE control_families (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(10) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    priority VARCHAR(20) NOT NULL CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    domain VARCHAR(30) NOT NULL CHECK (domain IN (
        'GOVERNANCE', 'SECURITY', 'PRIVACY', 'ETHICS', 'OPERATIONS', 
        'COMPLIANCE', 'RISK_MANAGEMENT', 'QUALITY_ASSURANCE'
    )),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Control Categories Table
CREATE TABLE control_categories (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    control_family_id BIGINT NOT NULL REFERENCES control_families(id) ON DELETE CASCADE,
    priority VARCHAR(20) NOT NULL CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(control_family_id, code)
);

-- Controls Table
CREATE TABLE controls (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(30) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    objective TEXT,
    implementation_guidance TEXT,
    assessment_procedure TEXT,
    control_category_id BIGINT NOT NULL REFERENCES control_categories(id) ON DELETE CASCADE,
    priority VARCHAR(20) NOT NULL CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    type VARCHAR(20) NOT NULL CHECK (type IN ('PREVENTIVE', 'DETECTIVE', 'CORRECTIVE', 'COMPENSATING', 'DIRECTIVE')),
    is_implemented BOOLEAN NOT NULL DEFAULT FALSE,
    is_automated BOOLEAN NOT NULL DEFAULT FALSE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    last_assessment_date TIMESTAMP,
    effectiveness VARCHAR(30) CHECK (effectiveness IN (
        'NOT_ASSESSED', 'INEFFECTIVE', 'PARTIALLY_EFFECTIVE', 'LARGELY_EFFECTIVE', 'FULLY_EFFECTIVE'
    )),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(control_category_id, code)
);

-- Control Lifecycle Stages Junction Table
CREATE TABLE control_lifecycle_stages (
    control_id BIGINT NOT NULL REFERENCES controls(id) ON DELETE CASCADE,
    lifecycle_stages VARCHAR(20) NOT NULL CHECK (lifecycle_stages IN ('DESIGN', 'DEVELOPMENT', 'DEPLOYMENT', 'OPERATION', 'DECOMMISSIONING')),
    PRIMARY KEY (control_id, lifecycle_stages)
);

-- Control AI Characteristics Junction Table
CREATE TABLE control_ai_characteristics (
    control_id BIGINT NOT NULL REFERENCES controls(id) ON DELETE CASCADE,
    ai_characteristics VARCHAR(50) NOT NULL CHECK (ai_characteristics IN (
        'ACCOUNTABLE_TRANSPARENT', 'EXPLAINABLE_INTERPRETABLE', 'FAIR_BIAS_MANAGED',
        'PRIVACY_ENHANCED', 'SAFE', 'SECURE_RESILIENT', 'VALID_RELIABLE'
    )),
    PRIMARY KEY (control_id, ai_characteristics)
);

-- Explainability Dimensions Table
CREATE TABLE explainability_dimensions (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(30) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(30) NOT NULL CHECK (type IN (
        'RATIONALE', 'RESPONSIBILITY', 'DATA', 'FAIRNESS', 'SAFETY_PERFORMANCE', 'IMPACT'
    )),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Explainability Evidence Types Table
CREATE TABLE explainability_evidence_types (
    explainability_dimension_id BIGINT NOT NULL REFERENCES explainability_dimensions(id) ON DELETE CASCADE,
    evidence_types VARCHAR(255) NOT NULL,
    PRIMARY KEY (explainability_dimension_id, evidence_types)
);

-- Explainability Assessment Types Table
CREATE TABLE explainability_assessment_types (
    explainability_dimension_id BIGINT NOT NULL REFERENCES explainability_dimensions(id) ON DELETE CASCADE,
    assessment_types VARCHAR(255) NOT NULL,
    PRIMARY KEY (explainability_dimension_id, assessment_types)
);

-- Explainability Assessment Methods Table
CREATE TABLE explainability_assessment_methods (
    explainability_dimension_id BIGINT NOT NULL REFERENCES explainability_dimensions(id) ON DELETE CASCADE,
    assessment_methods VARCHAR(255) NOT NULL,
    PRIMARY KEY (explainability_dimension_id, assessment_methods)
);

-- Create indexes for performance
CREATE INDEX idx_risk_categories_code ON risk_categories(code);
CREATE INDEX idx_risk_categories_severity ON risk_categories(severity);
CREATE INDEX idx_risk_categories_active ON risk_categories(is_active);

CREATE INDEX idx_control_families_code ON control_families(code);
CREATE INDEX idx_control_families_domain ON control_families(domain);
CREATE INDEX idx_control_families_active ON control_families(is_active);

CREATE INDEX idx_control_categories_family ON control_categories(control_family_id);
CREATE INDEX idx_control_categories_active ON control_categories(is_active);

CREATE INDEX idx_controls_category ON controls(control_category_id);
CREATE INDEX idx_controls_priority ON controls(priority);
CREATE INDEX idx_controls_type ON controls(type);
CREATE INDEX idx_controls_implemented ON controls(is_implemented);
CREATE INDEX idx_controls_effectiveness ON controls(effectiveness);
CREATE INDEX idx_controls_active ON controls(is_active);

CREATE INDEX idx_explainability_dimensions_type ON explainability_dimensions(type);
CREATE INDEX idx_explainability_dimensions_active ON explainability_dimensions(is_active);

-- Create update timestamp triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_risk_categories_updated_at BEFORE UPDATE ON risk_categories
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_control_families_updated_at BEFORE UPDATE ON control_families
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_control_categories_updated_at BEFORE UPDATE ON control_categories
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_controls_updated_at BEFORE UPDATE ON controls
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_explainability_dimensions_updated_at BEFORE UPDATE ON explainability_dimensions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Add comments for documentation
COMMENT ON TABLE risk_categories IS 'NIST AI 600-1 GAI Risk Categories';
COMMENT ON TABLE control_families IS 'ISACA AI Audit Toolkit Control Families';
COMMENT ON TABLE control_categories IS 'Control Categories within Control Families';
COMMENT ON TABLE controls IS 'Individual Controls with assessment criteria';
COMMENT ON TABLE explainability_dimensions IS 'Six ISACA Explainability Dimensions';

COMMENT ON COLUMN risk_categories.code IS 'Unique risk category code (e.g., CBRN_INFO, CONFABULATION)';
COMMENT ON COLUMN risk_categories.severity IS 'Risk severity level based on potential impact';
COMMENT ON COLUMN risk_categories.likelihood IS 'Probability of risk materialization';
COMMENT ON COLUMN risk_categories.scope IS 'Scope of risk impact (model, application, ecosystem)';
COMMENT ON COLUMN risk_categories.time_scale IS 'Timeline for risk materialization';

COMMENT ON COLUMN control_families.code IS 'Unique control family code (e.g., ADR, BMF, DPR)';
COMMENT ON COLUMN control_families.domain IS 'Control domain classification';

COMMENT ON COLUMN controls.effectiveness IS 'Assessment result of control effectiveness';
COMMENT ON COLUMN controls.is_implemented IS 'Whether the control is currently implemented';
COMMENT ON COLUMN controls.is_automated IS 'Whether the control is automated or manual';

COMMENT ON COLUMN explainability_dimensions.type IS 'One of six explainability dimension types';

-- Grant permissions (adjust as needed for your environment)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO ai_audit_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ai_audit_user;
