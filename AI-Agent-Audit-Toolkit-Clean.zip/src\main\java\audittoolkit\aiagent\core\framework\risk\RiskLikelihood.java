package audittoolkit.aiagent.core.framework.risk;

/**
 * Risk likelihood levels for AI systems based on NIST AI Risk Management Framework.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public enum RiskLikelihood {
    
    VERY_LOW(0.1, "Very Low", "Extremely unlikely to occur (0-5% probability)"),
    LOW(0.3, "Low", "Unlikely to occur (5-25% probability)"),
    MEDIUM(0.5, "Medium", "Moderately likely to occur (25-75% probability)"),
    HIGH(0.7, "High", "Likely to occur (75-95% probability)"),
    VERY_HIGH(0.9, "Very High", "Almost certain to occur (95-100% probability)");

    private final double weight;
    private final String displayName;
    private final String description;

    RiskLikelihood(double weight, String displayName, String description) {
        this.weight = weight;
        this.displayName = displayName;
        this.description = description;
    }

    public double getWeight() {
        return weight;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Get likelihood level from probability percentage
     */
    public static RiskLikelihood fromProbability(double probability) {
        if (probability >= 0.95) return VERY_HIGH;
        if (probability >= 0.75) return HIGH;
        if (probability >= 0.25) return MEDIUM;
        if (probability >= 0.05) return LOW;
        return VERY_LOW;
    }

    /**
     * Check if this likelihood requires proactive monitoring
     */
    public boolean requiresProactiveMonitoring() {
        return this == HIGH || this == VERY_HIGH;
    }

    /**
     * Get probability range as string
     */
    public String getProbabilityRange() {
        switch (this) {
            case VERY_LOW: return "0-5%";
            case LOW: return "5-25%";
            case MEDIUM: return "25-75%";
            case HIGH: return "75-95%";
            case VERY_HIGH: return "95-100%";
            default: return "Unknown";
        }
    }
}
