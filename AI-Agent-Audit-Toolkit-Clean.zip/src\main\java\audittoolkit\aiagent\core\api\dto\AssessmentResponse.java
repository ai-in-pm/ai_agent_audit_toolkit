package audittoolkit.aiagent.core.api.dto;

import audittoolkit.aiagent.core.assessment.reporting.AssessmentReport;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Response DTO for AI system assessments.
 * 
 * © 2024 Darrell Mesa. All rights reserved.
 * Owner: Darrell Mesa (darrell.mesa@pm-ss.org)
 * Not for commercial use.
 */
public class AssessmentResponse {

    private String assessmentId;
    private String systemName;
    private AssessmentStatus status;
    private String methodology;
    private AssessmentSummary summary;
    private ComplianceResults complianceResults;
    private RiskResults riskResults;
    private List<Finding> findings;
    private List<Recommendation> recommendations;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endTime;
    
    private String message;
    private List<String> errors;
    private Map<String, Object> metadata;

    // Constructors
    public AssessmentResponse() {}

    public AssessmentResponse(String assessmentId, AssessmentStatus status, String message) {
        this.assessmentId = assessmentId;
        this.status = status;
        this.message = message;
    }

    // Factory methods
    public static AssessmentResponse fromReport(AssessmentReport report) {
        AssessmentResponse response = new AssessmentResponse();
        response.setAssessmentId(report.getAssessmentId());
        response.setSystemName(report.getSystemProfile().getSystemName());
        response.setStatus(AssessmentStatus.valueOf(report.getStatus().name()));
        response.setMethodology(report.getMethodology().getName());
        response.setStartTime(report.getStartTime());
        response.setEndTime(report.getEndTime());
        
        // Create summary
        AssessmentSummary summary = new AssessmentSummary();
        summary.setTotalControls(report.getTotalControls());
        summary.setAssessedControls(report.getAssessedControls());
        summary.setCompliancePercentage(report.getOverallCompliancePercentage());
        summary.setRiskScore(report.getOverallRiskScore());
        response.setSummary(summary);
        
        return response;
    }

    public static AssessmentResponse error(String message) {
        AssessmentResponse response = new AssessmentResponse();
        response.setStatus(AssessmentStatus.FAILED);
        response.setMessage(message);
        return response;
    }

    // Getters and Setters
    public String getAssessmentId() { return assessmentId; }
    public void setAssessmentId(String assessmentId) { this.assessmentId = assessmentId; }

    public String getSystemName() { return systemName; }
    public void setSystemName(String systemName) { this.systemName = systemName; }

    public AssessmentStatus getStatus() { return status; }
    public void setStatus(AssessmentStatus status) { this.status = status; }

    public String getMethodology() { return methodology; }
    public void setMethodology(String methodology) { this.methodology = methodology; }

    public AssessmentSummary getSummary() { return summary; }
    public void setSummary(AssessmentSummary summary) { this.summary = summary; }

    public ComplianceResults getComplianceResults() { return complianceResults; }
    public void setComplianceResults(ComplianceResults complianceResults) { this.complianceResults = complianceResults; }

    public RiskResults getRiskResults() { return riskResults; }
    public void setRiskResults(RiskResults riskResults) { this.riskResults = riskResults; }

    public List<Finding> getFindings() { return findings; }
    public void setFindings(List<Finding> findings) { this.findings = findings; }

    public List<Recommendation> getRecommendations() { return recommendations; }
    public void setRecommendations(List<Recommendation> recommendations) { this.recommendations = recommendations; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public List<String> getErrors() { return errors; }
    public void setErrors(List<String> errors) { this.errors = errors; }

    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }

    // Inner classes
    public enum AssessmentStatus {
        PENDING("Assessment is pending execution"),
        RUNNING("Assessment is currently running"),
        COMPLETED("Assessment completed successfully"),
        FAILED("Assessment failed"),
        CANCELLED("Assessment was cancelled");

        private final String description;

        AssessmentStatus(String description) {
            this.description = description;
        }

        public String getDescription() { return description; }
    }

    public static class AssessmentSummary {
        private int totalControls;
        private int assessedControls;
        private int implementedControls;
        private int effectiveControls;
        private double compliancePercentage;
        private double riskScore;
        private String overallRating;
        private Map<String, Integer> controlsByPriority;
        private Map<String, Integer> risksByCategory;

        // Getters and Setters
        public int getTotalControls() { return totalControls; }
        public void setTotalControls(int totalControls) { this.totalControls = totalControls; }

        public int getAssessedControls() { return assessedControls; }
        public void setAssessedControls(int assessedControls) { this.assessedControls = assessedControls; }

        public int getImplementedControls() { return implementedControls; }
        public void setImplementedControls(int implementedControls) { this.implementedControls = implementedControls; }

        public int getEffectiveControls() { return effectiveControls; }
        public void setEffectiveControls(int effectiveControls) { this.effectiveControls = effectiveControls; }

        public double getCompliancePercentage() { return compliancePercentage; }
        public void setCompliancePercentage(double compliancePercentage) { this.compliancePercentage = compliancePercentage; }

        public double getRiskScore() { return riskScore; }
        public void setRiskScore(double riskScore) { this.riskScore = riskScore; }

        public String getOverallRating() { return overallRating; }
        public void setOverallRating(String overallRating) { this.overallRating = overallRating; }

        public Map<String, Integer> getControlsByPriority() { return controlsByPriority; }
        public void setControlsByPriority(Map<String, Integer> controlsByPriority) { this.controlsByPriority = controlsByPriority; }

        public Map<String, Integer> getRisksByCategory() { return risksByCategory; }
        public void setRisksByCategory(Map<String, Integer> risksByCategory) { this.risksByCategory = risksByCategory; }
    }

    public static class ComplianceResults {
        private Map<String, Double> frameworkCompliance;
        private Map<String, String> frameworkStatus;
        private List<ComplianceGap> gaps;
        private int totalRequirements;
        private int metRequirements;

        // Getters and Setters
        public Map<String, Double> getFrameworkCompliance() { return frameworkCompliance; }
        public void setFrameworkCompliance(Map<String, Double> frameworkCompliance) { this.frameworkCompliance = frameworkCompliance; }

        public Map<String, String> getFrameworkStatus() { return frameworkStatus; }
        public void setFrameworkStatus(Map<String, String> frameworkStatus) { this.frameworkStatus = frameworkStatus; }

        public List<ComplianceGap> getGaps() { return gaps; }
        public void setGaps(List<ComplianceGap> gaps) { this.gaps = gaps; }

        public int getTotalRequirements() { return totalRequirements; }
        public void setTotalRequirements(int totalRequirements) { this.totalRequirements = totalRequirements; }

        public int getMetRequirements() { return metRequirements; }
        public void setMetRequirements(int metRequirements) { this.metRequirements = metRequirements; }
    }

    public static class RiskResults {
        private double overallRiskScore;
        private String riskLevel;
        private Map<String, Double> riskByCategory;
        private List<HighRiskItem> highRiskItems;
        private int totalRisks;
        private int mitigatedRisks;

        // Getters and Setters
        public double getOverallRiskScore() { return overallRiskScore; }
        public void setOverallRiskScore(double overallRiskScore) { this.overallRiskScore = overallRiskScore; }

        public String getRiskLevel() { return riskLevel; }
        public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }

        public Map<String, Double> getRiskByCategory() { return riskByCategory; }
        public void setRiskByCategory(Map<String, Double> riskByCategory) { this.riskByCategory = riskByCategory; }

        public List<HighRiskItem> getHighRiskItems() { return highRiskItems; }
        public void setHighRiskItems(List<HighRiskItem> highRiskItems) { this.highRiskItems = highRiskItems; }

        public int getTotalRisks() { return totalRisks; }
        public void setTotalRisks(int totalRisks) { this.totalRisks = totalRisks; }

        public int getMitigatedRisks() { return mitigatedRisks; }
        public void setMitigatedRisks(int mitigatedRisks) { this.mitigatedRisks = mitigatedRisks; }
    }

    public static class Finding {
        private String id;
        private String type;
        private String severity;
        private String title;
        private String description;
        private String controlCode;
        private String riskCategory;
        private String evidence;
        private String recommendation;

        // Getters and Setters
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }

        public String getType() { return type; }
        public void setType(String type) { this.type = type; }

        public String getSeverity() { return severity; }
        public void setSeverity(String severity) { this.severity = severity; }

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public String getControlCode() { return controlCode; }
        public void setControlCode(String controlCode) { this.controlCode = controlCode; }

        public String getRiskCategory() { return riskCategory; }
        public void setRiskCategory(String riskCategory) { this.riskCategory = riskCategory; }

        public String getEvidence() { return evidence; }
        public void setEvidence(String evidence) { this.evidence = evidence; }

        public String getRecommendation() { return recommendation; }
        public void setRecommendation(String recommendation) { this.recommendation = recommendation; }
    }

    public static class Recommendation {
        private String id;
        private String priority;
        private String title;
        private String description;
        private String category;
        private int estimatedEffort;
        private String timeframe;
        private List<String> relatedControls;

        // Getters and Setters
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }

        public String getPriority() { return priority; }
        public void setPriority(String priority) { this.priority = priority; }

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }

        public int getEstimatedEffort() { return estimatedEffort; }
        public void setEstimatedEffort(int estimatedEffort) { this.estimatedEffort = estimatedEffort; }

        public String getTimeframe() { return timeframe; }
        public void setTimeframe(String timeframe) { this.timeframe = timeframe; }

        public List<String> getRelatedControls() { return relatedControls; }
        public void setRelatedControls(List<String> relatedControls) { this.relatedControls = relatedControls; }
    }

    public static class ComplianceGap {
        private String framework;
        private String requirement;
        private String status;
        private String description;

        // Getters and Setters
        public String getFramework() { return framework; }
        public void setFramework(String framework) { this.framework = framework; }

        public String getRequirement() { return requirement; }
        public void setRequirement(String requirement) { this.requirement = requirement; }

        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
    }

    public static class HighRiskItem {
        private String riskCode;
        private String riskName;
        private double riskScore;
        private String severity;
        private String likelihood;
        private String description;

        // Getters and Setters
        public String getRiskCode() { return riskCode; }
        public void setRiskCode(String riskCode) { this.riskCode = riskCode; }

        public String getRiskName() { return riskName; }
        public void setRiskName(String riskName) { this.riskName = riskName; }

        public double getRiskScore() { return riskScore; }
        public void setRiskScore(double riskScore) { this.riskScore = riskScore; }

        public String getSeverity() { return severity; }
        public void setSeverity(String severity) { this.severity = severity; }

        public String getLikelihood() { return likelihood; }
        public void setLikelihood(String likelihood) { this.likelihood = likelihood; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
    }
}
